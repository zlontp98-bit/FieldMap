package com.fibra.fieldmapweb;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQ = 1001;
    private static final int LOCATION_REQ = 1;
    private static final Pattern URL_RE = Pattern.compile("https?://[^\\s<>\"]+");
    /** Точка, присланная через «Поделиться», пока страница её не забрала (JSON: text, urls). */
    private volatile String pendingShare;

    /** Мост для JS: отправка экспортированного файла в другие приложения. */
    public class Bridge {
        @JavascriptInterface
        public void shareFile(final String name, final String mime, final String text) {
            try {
                File dir = new File(getCacheDir(), "exports");
                if (!dir.exists()) dir.mkdirs();
                String safe = name.replaceAll("[^A-Za-z0-9._-]", "_");
                File f = new File(dir, safe);
                FileOutputStream out = new FileOutputStream(f);
                try { out.write(text.getBytes(StandardCharsets.UTF_8)); } finally { out.close(); }
                final Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                final String type = mime;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType(type);
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send, "Отправить файл"));
                    }
                });
            } catch (final Exception e) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Toast.makeText(MainActivity.this, "Не удалось экспортировать: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        }

        /** Отправить текст (координаты маркера и ссылку) в WhatsApp, Telegram, почту и т.д. */
        @JavascriptInterface
        public void shareText(final String text) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(send, "Отправить точку"));
                }
            });
        }

        /** Открыть точку в Google Картах (если их нет — в другом приложении карт или в браузере). */
        @JavascriptInterface
        public void openMap(final double lat, final double lng, final String name) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    String ll = lat + "," + lng;
                    Uri geo = Uri.parse("geo:" + ll + "?q=" + ll + "(" + Uri.encode(name == null ? "" : name) + ")");
                    Intent maps = new Intent(Intent.ACTION_VIEW, geo).setPackage("com.google.android.apps.maps");
                    Intent any = new Intent(Intent.ACTION_VIEW, geo);
                    Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + ll));
                    for (Intent i : new Intent[]{maps, any, web}) {
                        try { startActivity(i); return; } catch (ActivityNotFoundException ignored) {}
                    }
                }
            });
        }

        /** Страница при запуске забирает точку, присланную до её загрузки. */
        @JavascriptInterface
        public String takeShared() {
            String p = pendingShare;
            pendingShare = null;
            return p;
        }

        /** Повторный запрос разрешения на геолокацию (кнопка ◎, если доступа нет). Ответ — в window.__onLocationPermission. */
        @JavascriptInterface
        public void requestLocationPermission() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                            || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        notifyLocationPermission(true);
                    } else {
                        requestPermissions(new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                        }, LOCATION_REQ);
                    }
                }
            });
        }
    }

    private void notifyLocationPermission(boolean granted) {
        if (web == null) return;
        web.evaluateJavascript("window.__onLocationPermission && window.__onLocationPermission(" + granted + ")", null);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setLongClickable(false);
        web.setOnLongClickListener(v -> true);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage и IndexedDB (кэш Firebase)
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setSupportZoom(false);               // щипок обрабатывает сама карта (canvas)
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        try { s.setGeolocationEnabled(true); } catch (Throwable ignored) {}

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, LOCATION_REQ);
        }

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                // показываем ошибку только для главной страницы, а не для отдельных тайлов/скриптов
                if (req != null && req.isForMainFrame()) {
                    String msg = "Ошибка загрузки: " + err.getErrorCode() + " " + err.getDescription();
                    view.loadData("<pre style='padding:16px;font:16px/1.4 monospace'>" + msg + "</pre>",
                            "text/html; charset=utf-8", "utf-8");
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }

            // выбор файла: фото (image/*) и импорт KML (любой тип) — параметры берём у самой страницы
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_CHOOSER_REQ);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
            }
        });

        web.loadUrl("file:///android_asset/web/index.html");
        handleShareIntent(getIntent());
    }

    // приложение уже открыто, а в него снова что-то прислали (launchMode singleTask)
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleShareIntent(intent);
    }

    // «Поделиться» из Google Карт, WhatsApp и т.п. (текст со ссылкой) или ссылка geo:
    private void handleShareIntent(Intent intent) {
        if (intent == null) return;
        String text = null;
        if (Intent.ACTION_SEND.equals(intent.getAction())) {
            CharSequence t = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
            String subject = intent.getStringExtra(Intent.EXTRA_SUBJECT);
            text = (subject != null && (t == null || !t.toString().contains(subject)) ? subject + "\n" : "") + (t != null ? t : "");
        } else if (Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
            text = intent.getData().toString();
        }
        if (text == null || text.trim().isEmpty()) return;
        setIntent(new Intent(this, MainActivity.class));   // повторно (при повороте экрана) не обрабатываем
        final String shared = text;
        new Thread(new Runnable() {
            @Override public void run() {
                JSONArray urls = new JSONArray();
                Matcher m = URL_RE.matcher(shared);
                while (m.find()) for (String u : expandUrl(m.group())) urls.put(u);
                try {
                    JSONObject o = new JSONObject();
                    o.put("text", shared);
                    o.put("urls", urls);
                    pendingShare = o.toString();
                } catch (Exception ignored) { return; }
                runOnUiThread(new Runnable() { @Override public void run() { deliverShare(); } });
            }
        }).start();
    }

    // короткие ссылки Google Карт (maps.app.goo.gl) не содержат координат: проходим по перенаправлениям
    // и возвращаем все адреса по пути — в одном из них есть координаты
    private static List<String> expandUrl(String start) {
        List<String> out = new ArrayList<>();
        out.add(start);
        String cur = start;
        for (int i = 0; i < 8; i++) {
            String host = Uri.parse(cur).getHost();
            if (host == null || !(host.endsWith("goo.gl") || host.endsWith("g.co") || host.contains("google."))) break;
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(cur).openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(8000);
                c.setReadTimeout(8000);
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36");
                int code = c.getResponseCode();
                String loc = c.getHeaderField("Location");
                if (code < 300 || code >= 400 || loc == null) break;
                cur = new URL(new URL(cur), loc).toString();
                out.add(cur);
            } catch (Exception e) {
                break;
            } finally {
                if (c != null) c.disconnect();
            }
        }
        return out;
    }

    // передаём точку странице; если она ещё не загрузилась — заберёт сама через takeShared()
    private void deliverShare() {
        final String p = pendingShare;
        if (p == null || web == null) return;
        String js = "(window.__onSharedLocation ? (window.__onSharedLocation(" + JSONObject.quote(p) + "), 'ok') : 'wait')";
        web.evaluateJavascript(js, new ValueCallback<String>() {
            @Override public void onReceiveValue(String r) {
                if ("\"ok\"".equals(r) && p.equals(pendingShare)) pendingShare = null;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQ && fileCallback != null) {
            fileCallback.onReceiveValue(chosenFiles(resultCode, data));
            fileCallback = null;
        }
    }

    // parseResult берёт только один файл; при выборе нескольких фото они приходят в ClipData
    private static Uri[] chosenFiles(int resultCode, Intent data) {
        if (resultCode != RESULT_OK || data == null) return null;
        ClipData clip = data.getClipData();
        if (clip != null && clip.getItemCount() > 0) {
            Uri[] out = new Uri[clip.getItemCount()];
            for (int i = 0; i < out.length; i++) out[i] = clip.getItemAt(i).getUri();
            return out;
        }
        return WebChromeClient.FileChooserParams.parseResult(resultCode, data);
    }

    // после ответа на запрос геолокации сообщаем странице: она сама перезапускает слежение (без перезагрузки)
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQ) {
            boolean granted = false;
            for (int r : grantResults) if (r == PackageManager.PERMISSION_GRANTED) { granted = true; break; }
            notifyLocationPermission(granted);
        }
    }

    // «Назад»: сначала закрываем лист/меню/режим добавления на странице, потом выходим
    @Override
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(window.__onBack ? window.__onBack() : false)", new ValueCallback<String>() {
            @Override public void onReceiveValue(String handled) {
                if (!"true".equals(handled)) finish();
            }
        });
    }
}
