package com.fibra.fieldmapweb;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialCancellationException;
import androidx.credentials.exceptions.GetCredentialException;
import androidx.credentials.exceptions.NoCredentialException;

import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQ = 1001;
    private static final int LOCATION_REQ = 1;
    private static final int CAMERA_REQ = 1002;
    private static final int SAVE_REQ = 1003;
    /** Куда камера кладёт снимок (файл в кэше, отдаётся странице как content://). */
    private Uri cameraUri;
    /** Файл, который страница просила сохранить: ждёт, пока человек выберет место. */
    private File pendingSave;
    private static final Pattern URL_RE = Pattern.compile("https?://[^\\s<>\"]+");
    /** Точка, присланная через «Поделиться», пока страница её не забрала (JSON: text, urls). */
    private volatile String pendingShare;

    /** Мост для JS: отправка экспортированного файла в другие приложения. */
    public class Bridge {
        @JavascriptInterface
        public void shareFile(final String name, final String mime, final String text) {
            try {
                File dir = new File(getCacheDir(), "exports");
                if (!dir.exists()) dir.mkdirs();
                File f = new File(dir, safeName(name));
                FileOutputStream out = new FileOutputStream(f);
                try { out.write(text.getBytes(StandardCharsets.UTF_8)); } finally { out.close(); }
                final Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                final String type = mime;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType(type);
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send, "Отправить файл"));
                    }
                });
            } catch (final Exception e) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Toast.makeText(MainActivity.this, "Не удалось экспортировать: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        }

        /** Отправить двоичный файл (PDF, фото) в другие приложения: данные приходят строкой base64. */
        @JavascriptInterface
        public void shareBinary(final String name, final String mime, final String b64) {
            try {
                final File f = writeExport(name, Base64.decode(b64, Base64.DEFAULT));
                final Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType(mime);
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send, "Отправить файл"));
                    }
                });
            } catch (final Exception e) {
                toastLong("Не удалось подготовить файл: " + e.getMessage());
            }
        }

        /** Сохранить двоичный файл туда, куда выберет человек (системное окно «Сохранить»). Ответ — в window.__onFileSaved. */
        @JavascriptInterface
        public void saveBinary(final String name, final String mime, final String b64) {
            try {
                pendingSave = writeExport(name, Base64.decode(b64, Base64.DEFAULT));
            } catch (Exception e) {
                toastLong("Не удалось подготовить файл: " + e.getMessage());
                notifySaved(false);
                return;
            }
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(mime);
                    i.putExtra(Intent.EXTRA_TITLE, name);
                    try { startActivityForResult(i, SAVE_REQ); }
                    catch (ActivityNotFoundException e) { notifySaved(false); }
                }
            });
        }

        /** Вход через Google: телефон показывает свои аккаунты (Credential Manager). Ответ — в window.__onGoogleSignIn. */
        @JavascriptInterface
        public void googleSignIn(final String webClientId) {
            runOnUiThread(new Runnable() {
                @Override public void run() { startGoogleSignIn(webClientId); }
            });
        }

        /** Отправить текст (координаты маркера и ссылку) в WhatsApp, Telegram, почту и т.д. */
        @JavascriptInterface
        public void shareText(final String text) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(send, "Отправить точку"));
                }
            });
        }

        /** Открыть точку в Google Картах (если их нет — в другом приложении карт или в браузере). */
        @JavascriptInterface
        public void openMap(final double lat, final double lng, final String name) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    String ll = lat + "," + lng;
                    Uri geo = Uri.parse("geo:" + ll + "?q=" + ll + "(" + Uri.encode(name == null ? "" : name) + ")");
                    Intent maps = new Intent(Intent.ACTION_VIEW, geo).setPackage("com.google.android.apps.maps");
                    Intent any = new Intent(Intent.ACTION_VIEW, geo);
                    Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + ll));
                    for (Intent i : new Intent[]{maps, any, web}) {
                        try { startActivity(i); return; } catch (ActivityNotFoundException ignored) {}
                    }
                }
            });
        }

        /** Страница при запуске забирает точку, присланную до её загрузки. */
        @JavascriptInterface
        public String takeShared() {
            String p = pendingShare;
            pendingShare = null;
            return p;
        }

        /** Повторный запрос разрешения на геолокацию (кнопка ◎, если доступа нет). Ответ — в window.__onLocationPermission. */
        @JavascriptInterface
        public void requestLocationPermission() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                            || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        notifyLocationPermission(true);
                    } else {
                        requestPermissions(new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                        }, LOCATION_REQ);
                    }
                }
            });
        }
    }

    private static String safeName(String name) {
        String s = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|\\r\\n\\t]", "_").trim();
        return s.isEmpty() ? "FieldMap" : s;
    }

    private File writeExport(String name, byte[] data) throws Exception {
        File dir = new File(getCacheDir(), "exports");
        if (!dir.exists()) dir.mkdirs();
        File f = new File(dir, safeName(name));
        FileOutputStream out = new FileOutputStream(f);
        try { out.write(data); } finally { out.close(); }
        return f;
    }

    private void toastLong(final String msg) {
        runOnUiThread(new Runnable() {
            @Override public void run() { Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show(); }
        });
    }

    private void notifySaved(final boolean ok) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (web != null) web.evaluateJavascript("window.__onFileSaved && window.__onFileSaved(" + ok + ")", null);
            }
        });
    }

    // ---------- вход через Google (Credential Manager → ID-токен → страница → Firebase) ----------
    private void startGoogleSignIn(String webClientId) {
        try {
            GetGoogleIdOption option = new GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)   // все Google-аккаунты телефона, не только входившие раньше
                    .setServerClientId(webClientId)
                    .setAutoSelectEnabled(false)
                    .build();
            GetCredentialRequest request = new GetCredentialRequest.Builder().addCredentialOption(option).build();
            CredentialManager.create(this).getCredentialAsync(this, request, new CancellationSignal(), ContextCompat.getMainExecutor(this),
                    new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                        @Override public void onResult(GetCredentialResponse response) { handleCredential(response.getCredential()); }
                        @Override public void onError(GetCredentialException e) { signInResult(null, signInError(e)); }
                    });
        } catch (Throwable t) {
            signInResult(null, "Не удалось открыть вход через Google: " + t.getMessage());
        }
    }

    private void handleCredential(Credential c) {
        if (c instanceof CustomCredential && GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(c.getType())) {
            try {
                GoogleIdTokenCredential g = GoogleIdTokenCredential.createFrom(c.getData());
                JSONObject o = new JSONObject();
                o.put("idToken", g.getIdToken());
                o.put("name", g.getDisplayName() == null ? "" : g.getDisplayName());
                o.put("email", g.getId());
                signInResult(o, null);
                return;
            } catch (Exception e) {
                signInResult(null, "Google вернул неверный ответ: " + e.getMessage());
                return;
            }
        }
        signInResult(null, "Google вернул неизвестный ответ");
    }

    private static String signInError(GetCredentialException e) {
        if (e instanceof GetCredentialCancellationException) return "Вход отменён";
        if (e instanceof NoCredentialException) return "На телефоне нет Google-аккаунта: добавьте его в настройках телефона";
        CharSequence m = e.getErrorMessage();
        return "Не удалось войти через Google" + (m != null ? ": " + m : "");
    }

    private void signInResult(JSONObject ok, String error) {
        try {
            JSONObject o = ok != null ? ok : new JSONObject().put("error", error);
            final String js = "window.__onGoogleSignIn && window.__onGoogleSignIn(" + JSONObject.quote(o.toString()) + ")";
            runOnUiThread(new Runnable() {
                @Override public void run() { if (web != null) web.evaluateJavascript(js, null); }
            });
        } catch (Exception ignored) {}
    }

    private void notifyLocationPermission(boolean granted) {
        if (web == null) return;
        web.evaluateJavascript("window.__onLocationPermission && window.__onLocationPermission(" + granted + ")", null);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setLongClickable(false);
        web.setOnLongClickListener(v -> true);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage и IndexedDB (кэш Firebase)
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setSupportZoom(false);               // щипок обрабатывает сама карта (canvas)
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        try { s.setGeolocationEnabled(true); } catch (Throwable ignored) {}

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, LOCATION_REQ);
        }

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                // показываем ошибку только для главной страницы, а не для отдельных тайлов/скриптов
                if (req != null && req.isForMainFrame()) {
                    String msg = "Ошибка загрузки: " + err.getErrorCode() + " " + err.getDescription();
                    view.loadData("<pre style='padding:16px;font:16px/1.4 monospace'>" + msg + "</pre>",
                            "text/html; charset=utf-8", "utf-8");
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }

            // выбор файла: фото (image/*) и импорт KML (любой тип) — параметры берём у самой страницы;
            // кнопка «камера» (capture) сразу открывает камеру телефона, снимок отдаётся странице
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                if (params.isCaptureEnabled() && acceptsImages(params) && openCamera()) return true;
                try {
                    startActivityForResult(params.createIntent(), FILE_CHOOSER_REQ);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
            }
        });

        web.loadUrl("file:///android_asset/web/index.html");
        handleShareIntent(getIntent());
    }

    private static boolean acceptsImages(WebChromeClient.FileChooserParams params) {
        String[] types = params.getAcceptTypes();
        if (types == null || types.length == 0) return true;
        for (String t : types) if (t == null || t.isEmpty() || t.startsWith("image")) return true;
        return false;
    }

    // камера телефона (без своего разрешения CAMERA: снимает приложение камеры); false — камеры нет
    private boolean openCamera() {
        try {
            File dir = new File(getCacheDir(), "photos");
            if (!dir.exists()) dir.mkdirs();
            File[] old = dir.listFiles();
            if (old != null) for (File x : old) if (System.currentTimeMillis() - x.lastModified() > 86400000L) x.delete();
            File f = new File(dir, "shot-" + System.currentTimeMillis() + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            cam.setClipData(ClipData.newRawUri("", cameraUri));
            cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(cam, CAMERA_REQ);
            return true;
        } catch (Exception e) {
            cameraUri = null;
            return false;
        }
    }

    // приложение уже открыто, а в него снова что-то прислали (launchMode singleTask)
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleShareIntent(intent);
    }

    // «Поделиться» из Google Карт, WhatsApp и т.п. (текст со ссылкой) или ссылка geo:
    private void handleShareIntent(Intent intent) {
        if (intent == null) return;
        String text = null;
        if (Intent.ACTION_SEND.equals(intent.getAction())) {
            CharSequence t = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
            String subject = intent.getStringExtra(Intent.EXTRA_SUBJECT);
            text = (subject != null && (t == null || !t.toString().contains(subject)) ? subject + "\n" : "") + (t != null ? t : "");
        } else if (Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
            text = intent.getData().toString();
        }
        if (text == null || text.trim().isEmpty()) return;
        setIntent(new Intent(this, MainActivity.class));   // повторно (при повороте экрана) не обрабатываем
        final String shared = text;
        new Thread(new Runnable() {
            @Override public void run() {
                JSONArray urls = new JSONArray();
                Matcher m = URL_RE.matcher(shared);
                while (m.find()) for (String u : expandUrl(m.group())) urls.put(u);
                try {
                    JSONObject o = new JSONObject();
                    o.put("text", shared);
                    o.put("urls", urls);
                    pendingShare = o.toString();
                } catch (Exception ignored) { return; }
                runOnUiThread(new Runnable() { @Override public void run() { deliverShare(); } });
            }
        }).start();
    }

    // короткие ссылки Google Карт (maps.app.goo.gl) не содержат координат: проходим по перенаправлениям
    // и возвращаем все адреса по пути — в одном из них есть координаты
    private static List<String> expandUrl(String start) {
        List<String> out = new ArrayList<>();
        out.add(start);
        String cur = start;
        for (int i = 0; i < 8; i++) {
            String host = Uri.parse(cur).getHost();
            if (host == null || !(host.endsWith("goo.gl") || host.endsWith("g.co") || host.contains("google."))) break;
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(cur).openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(8000);
                c.setReadTimeout(8000);
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36");
                int code = c.getResponseCode();
                String loc = c.getHeaderField("Location");
                if (code < 300 || code >= 400 || loc == null) break;
                cur = new URL(new URL(cur), loc).toString();
                out.add(cur);
            } catch (Exception e) {
                break;
            } finally {
                if (c != null) c.disconnect();
            }
        }
        return out;
    }

    // передаём точку странице; если она ещё не загрузилась — заберёт сама через takeShared()
    private void deliverShare() {
        final String p = pendingShare;
        if (p == null || web == null) return;
        String js = "(window.__onSharedLocation ? (window.__onSharedLocation(" + JSONObject.quote(p) + "), 'ok') : 'wait')";
        web.evaluateJavascript(js, new ValueCallback<String>() {
            @Override public void onReceiveValue(String r) {
                if ("\"ok\"".equals(r) && p.equals(pendingShare)) pendingShare = null;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQ && fileCallback != null) {
            fileCallback.onReceiveValue(chosenFiles(resultCode, data));
            fileCallback = null;
        } else if (requestCode == CAMERA_REQ && fileCallback != null) {
            fileCallback.onReceiveValue(resultCode == RESULT_OK && cameraUri != null ? new Uri[]{cameraUri} : null);
            fileCallback = null;
            cameraUri = null;
        } else if (requestCode == SAVE_REQ) {
            final File src = pendingSave;
            pendingSave = null;
            final Uri dest = resultCode == RESULT_OK && data != null ? data.getData() : null;
            if (src == null || dest == null) { notifySaved(false); return; }
            new Thread(new Runnable() {
                @Override public void run() {
                    boolean ok = false;
                    try {
                        InputStream in = new FileInputStream(src);
                        OutputStream out = getContentResolver().openOutputStream(dest);
                        try {
                            byte[] buf = new byte[65536];
                            int n;
                            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                            ok = true;
                        } finally { in.close(); if (out != null) out.close(); }
                    } catch (Exception e) {
                        toastLong("Не удалось сохранить файл: " + e.getMessage());
                    }
                    notifySaved(ok);
                }
            }).start();
        }
    }

    // parseResult берёт только один файл; при выборе нескольких фото они приходят в ClipData
    private static Uri[] chosenFiles(int resultCode, Intent data) {
        if (resultCode != RESULT_OK || data == null) return null;
        ClipData clip = data.getClipData();
        if (clip != null && clip.getItemCount() > 0) {
            Uri[] out = new Uri[clip.getItemCount()];
            for (int i = 0; i < out.length; i++) out[i] = clip.getItemAt(i).getUri();
            return out;
        }
        return WebChromeClient.FileChooserParams.parseResult(resultCode, data);
    }

    // после ответа на запрос геолокации сообщаем странице: она сама перезапускает слежение (без перезагрузки)
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQ) {
            boolean granted = false;
            for (int r : grantResults) if (r == PackageManager.PERMISSION_GRANTED) { granted = true; break; }
            notifyLocationPermission(granted);
        }
    }

    // «Назад»: сначала закрываем лист/меню/режим добавления на странице, потом выходим
    @Override
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(window.__onBack ? window.__onBack() : false)", new ValueCallback<String>() {
            @Override public void onReceiveValue(String handled) {
                if (!"true".equals(handled)) finish();
            }
        });
    }
}
