// ===== FieldMap: карта, папки, маркеры, линии, меню, листы редактирования =====
window.app = {
  map: null, layers: {}, tile: 'osm', labels: true,
  mk: new Map(), ln: new Map(), fg: new Map(),   // слои Leaflet по id объектов и папок
  addMode: false, query: '', ui: null, sheetKind: null,
};

// ---------- утилиты ----------
const $ = (id) => document.getElementById(id);

function el(tag, props, ...kids) {
  const e = document.createElement(tag);
  if (props) for (const k in props) {
    const v = props[k];
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'style') e.style.cssText = v;
    else if (k.startsWith('on')) e[k] = v;
    else if (v === true) e.setAttribute(k, '');
    else e.setAttribute(k, v);
  }
  kids.flat().forEach((c) => { if (c != null && c !== false) e.append(c.nodeType ? c : document.createTextNode(String(c))); });
  return e;
}

function pref(key, val) {
  try {
    if (val === undefined) return localStorage.getItem('fieldmap_' + key);
    localStorage.setItem('fieldmap_' + key, val);
  } catch (_) {}
  return null;
}

let toastTimer = null;
function toast(msg) {
  const t = $('toast'); if (!t) return;
  t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true; }, 2800);
}

function plural(n, f) {
  const a = Math.abs(n) % 100, b = a % 10;
  if (a > 10 && a < 20) return f[2];
  if (b > 1 && b < 5) return f[1];
  if (b === 1) return f[0];
  return f[2];
}

// уменьшаем фото (длинная сторона maxSide px, JPEG): так и localStorage, и общая база не переполняются
function compressImage(file, maxSide, quality) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      try {
        const k = Math.min(1, maxSide / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(img.width * k));
        c.height = Math.max(1, Math.round(img.height * k));
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        resolve(c.toDataURL('image/jpeg', quality));
      } catch (e) { reject(e); }
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('не удалось прочитать изображение')); };
    img.src = url;
  });
}

function lineLength(pts) {
  let t = 0;
  for (let i = 1; i < pts.length; i++) t += L.latLng(pts[i - 1][0], pts[i - 1][1]).distanceTo(L.latLng(pts[i][0], pts[i][1]));
  return t;
}
const formatLen = (m) => (m < 1000 ? `${m.toFixed(0)} м` : `${(m / 1000).toFixed(2)} км`);

// ---------- инициализация ----------
function initMap() {
  try {
    if (typeof L === 'undefined') throw new Error('Leaflet не загрузился (нужен интернет при первом запуске)');
    const a = window.app;
    Store.load();

    a.tile = pref('tile') === 'esri' ? 'esri' : 'osm';
    a.labels = pref('labels') !== '0';

    const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap' });
    const esri = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      { maxZoom: 19, attribution: '&copy; Esri, Maxar' });
    a.layers = { osm, esri };

    a.map = L.map('map', { zoomControl: false, attributionControl: true });
    a.layers[a.tile].addTo(a.map);
    restoreView();
    a.map.on('moveend', saveView);
    a.map.on('zoomend', updateLabelVisibility);

    $('fabTiles').onclick = toggleTiles;
    $('fabGps').onclick = () => { if (typeof window.toggleGPSCore === 'function') window.toggleGPSCore(); };
    $('fabAdd').onclick = toggleAddMenu;
    $('btnMenu').onclick = openDrawer;
    $('backdrop').onclick = closeDrawer;
    $('importInput').onchange = onImportFile;
    $('sheet').addEventListener('click', (e) => { if (e.target === $('sheet')) closeSheet(); });

    buildDrawer();
    Store.on(() => { scheduleRender(); });
    Sync.onStatus(() => { renderDrawer(); if (a.sheetKind === 'sync') openSyncSheet(); });
    renderAll();
    updateLabelVisibility();
    ensureAddMenuUI();
    ensureMeasureUI();
    Sync.autostart();
  } catch (e) {
    logErr('initMap: ' + (e && e.message || e));
  }
}

function restoreView() {
  const a = window.app;
  let v = null;
  try { v = JSON.parse(pref('view')); } catch (_) {}
  if (v && Number.isFinite(v.lat) && Number.isFinite(v.lng) && Number.isFinite(v.z)) { a.map.setView([v.lat, v.lng], v.z); return; }
  const pts = allPoints();
  if (pts.length) a.map.fitBounds(L.latLngBounds(pts), { padding: [40, 40], maxZoom: 17 });
  else a.map.setView([44.411, 8.932], 16);
}
function saveView() {
  const c = window.app.map.getCenter();
  pref('view', JSON.stringify({ lat: c.lat, lng: c.lng, z: window.app.map.getZoom() }));
}

// ---------- тайлы и подписи ----------
function toggleTiles() {
  const a = window.app;
  const next = a.tile === 'osm' ? 'esri' : 'osm';
  a.map.removeLayer(a.layers[a.tile]);
  a.layers[next].addTo(a.map);
  a.tile = next; pref('tile', next);
  renderDrawer();
}
function toggleLabels() {
  const a = window.app;
  a.labels = !a.labels; pref('labels', a.labels ? '1' : '0');
  updateLabelVisibility(); renderDrawer();
}
function updateLabelVisibility() {
  const a = window.app, m = $('map');
  if (!m || !a.map) return;
  m.classList.toggle('hide-labels', !a.labels || a.map.getZoom() < 14);
}

// ---------- отрисовка объектов на карте (по данным Store) ----------
let renderTimer = null;
function scheduleRender() {
  if (renderTimer) return;
  renderTimer = setTimeout(() => { renderTimer = null; renderAll(); }, 0);
}

function folderGroup(fid) {
  const a = window.app;
  let g = a.fg.get(fid);
  if (!g) { g = L.layerGroup(); a.fg.set(fid, g); }
  return g;
}
function placeIn(layer, fid) {
  if (layer._fid === fid) return;
  if (layer._fid !== undefined) folderGroup(layer._fid).removeLayer(layer);
  folderGroup(fid).addLayer(layer);
  layer._fid = fid;
}

const PIN_SVG = '<svg viewBox="0 0 24 32" width="30" height="40" aria-hidden="true"><path d="M12 1C5.9 1 1 5.9 1 12c0 8.4 11 19 11 19s11-10.6 11-19C23 5.9 18.1 1 12 1z" fill="var(--c)" stroke="#111" stroke-width="1.6"/><circle cx="12" cy="12" r="4.4" fill="#fff"/></svg>';

function markerIcon(m, color) {
  if (m.photo) {
    const d = el('div', { class: 'pin-photo', style: `border-color:${color}` });
    const img = new Image(); img.src = m.photo; d.append(img);
    return L.divIcon({ className: '', html: d, iconSize: [46, 46], iconAnchor: [23, 46] });
  }
  const d = el('div', { class: 'pin', style: `--c:${color}` });
  d.innerHTML = PIN_SVG; // статичная разметка, пользовательских данных внутри нет
  return L.divIcon({ className: '', html: d, iconSize: [30, 40], iconAnchor: [15, 40] });
}

const label = (text) => el('span', null, text); // подпись как текстовый узел, а не HTML

function renderAll() {
  const a = window.app; if (!a.map) return;
  const folders = Store.live('folders');
  const fids = new Set(folders.map((f) => f.id));

  // маркеры
  const liveM = new Set();
  Store.live('markers').forEach((m) => {
    liveM.add(m.id);
    const color = m.color || Store.folderColor(m.folderId);
    let lyr = a.mk.get(m.id);
    if (!lyr) {
      lyr = L.marker([m.lat, m.lng], { draggable: true });
      lyr.on('click', () => editMarker(m.id));
      lyr.on('dragend', () => {
        const cur = Store.get('markers', m.id); const ll = lyr.getLatLng();
        if (cur && !cur.deleted) Store.upsert('markers', Object.assign({}, cur, { lat: ll.lat, lng: ll.lng }));
      });
      a.mk.set(m.id, lyr);
    } else {
      const ll = lyr.getLatLng();
      if (ll.lat !== m.lat || ll.lng !== m.lng) lyr.setLatLng([m.lat, m.lng]);
    }
    const sig = color + '|' + (m.photo ? m.photo.length + m.photo.slice(-24) : '');
    if (lyr._sig !== sig) { lyr.setIcon(markerIcon(m, color)); lyr._sig = sig; }
    if (m.name) {
      const off = [0, m.photo ? -50 : -42];
      if (lyr.getTooltip()) lyr.setTooltipContent(label(m.name));
      else lyr.bindTooltip(label(m.name), { permanent: true, direction: 'top', offset: off, className: 'mk-label' });
    } else if (lyr.getTooltip()) lyr.unbindTooltip();
    placeIn(lyr, fids.has(m.folderId) ? m.folderId : '_orphan');
  });
  for (const [id, lyr] of a.mk) if (!liveM.has(id)) { folderGroup(lyr._fid).removeLayer(lyr); a.mk.delete(id); }

  // линии
  const liveL = new Set();
  Store.live('lines').forEach((l) => {
    liveL.add(l.id);
    const color = l.color || Store.folderColor(l.folderId);
    let pl = a.ln.get(l.id);
    if (!pl) {
      pl = L.polyline(l.points, { color, weight: 4 });
      pl.on('click', () => editLine(l.id));
      a.ln.set(l.id, pl);
    } else { pl.setLatLngs(l.points); pl.setStyle({ color }); }
    const text = (l.name ? l.name + ' • ' : '') + formatLen(lineLength(l.points));
    if (pl.getTooltip()) pl.setTooltipContent(label(text));
    else pl.bindTooltip(label(text), { permanent: true, direction: 'center', className: 'line-label' });
    placeIn(pl, fids.has(l.folderId) ? l.folderId : '_orphan');
  });
  for (const [id, pl] of a.ln) if (!liveL.has(id)) { folderGroup(pl._fid).removeLayer(pl); a.ln.delete(id); }

  // видимость папок (личная настройка)
  [...folders.map((f) => f.id), '_orphan'].forEach((fid) => {
    const g = folderGroup(fid), vis = !Store.isHidden(fid);
    if (vis && !a.map.hasLayer(g)) a.map.addLayer(g);
    else if (!vis && a.map.hasLayer(g)) a.map.removeLayer(g);
  });
  renderDrawer();
}

function allPoints(folderId) {
  const pts = [];
  Store.live('markers').forEach((m) => { if (!folderId || m.folderId === folderId) pts.push([m.lat, m.lng]); });
  Store.live('lines').forEach((l) => { if (!folderId || l.folderId === folderId) l.points.forEach((p) => pts.push(p)); });
  return pts;
}
function fitTo(folderId) {
  const pts = allPoints(folderId);
  if (!pts.length) { toast('Здесь пока ничего нет'); return; }
  window.app.map.fitBounds(L.latLngBounds(pts), { padding: [50, 50], maxZoom: 18 });
}

// ---------- боковое меню ----------
function openDrawer() { renderDrawer(); $('drawer').classList.add('open'); $('backdrop').hidden = false; }
function closeDrawer() { $('drawer').classList.remove('open'); $('backdrop').hidden = true; }
const drawerOpen = () => $('drawer').classList.contains('open');

function setRow(row, icon, title, sub) {
  row.textContent = '';
  row.append(el('div', { class: 'ico' }, icon), el('div', { class: 'txt' }, el('div', { class: 'ttl' }, title), sub ? el('div', { class: 'sub' }, sub) : null));
}

function buildDrawer() {
  const a = window.app, body = $('drawerBody');
  body.textContent = '';
  a.ui = {};
  a.ui.syncRow = el('button', { class: 'row', onclick: () => { closeDrawer(); openSyncSheet(); } });
  a.ui.tileRow = el('button', { class: 'row', onclick: toggleTiles });
  a.ui.labelRow = el('button', { class: 'row', onclick: toggleLabels });
  a.ui.search = el('input', {
    type: 'search', class: 'inp', placeholder: 'Поиск по названию',
    oninput: (e) => { a.query = e.target.value.trim().toLowerCase(); renderDrawer(); },
  });
  a.ui.list = el('div', { class: 'list', id: 'folderList' });
  body.append(
    el('div', { class: 'sec' }, 'карта'),
    el('div', { class: 'list' }, a.ui.syncRow, a.ui.tileRow, a.ui.labelRow),
    el('div', { class: 'sec' }, 'папки'),
    el('div', { class: 'search-wrap' }, a.ui.search),
    a.ui.list,
    el('div', { class: 'sec' }, 'данные'),
    el('div', { class: 'list' },
      el('button', { class: 'row', onclick: () => { closeDrawer(); $('importInput').click(); } },
        el('div', { class: 'ico' }, '📥'), el('div', { class: 'txt' }, el('div', { class: 'ttl' }, 'Импорт KML'), el('div', { class: 'sub' }, 'Папки и точки из Google Earth, Map Marker и др.'))),
      el('button', { class: 'row', onclick: exportKml },
        el('div', { class: 'ico' }, '📤'), el('div', { class: 'txt' }, el('div', { class: 'ttl' }, 'Экспорт KML'), el('div', { class: 'sub' }, 'Отправить все папки файлом (без фото)')))),
  );
}

function syncLabel() {
  const st = Sync.status(), id = Store.state.mapId;
  if (!Sync.configured()) return 'Не настроено (см. README)';
  if (!id) return 'Не подключено — нажмите, чтобы подключить';
  const code = Sync.pretty(id);
  if (st.state === 'online') {
    const t = st.last ? new Date(st.last).toLocaleString('ru-RU', { dateStyle: 'short', timeStyle: 'medium' }) : '';
    return 'Подключено · код ' + code + (t ? ' · синхронизация: ' + t : '');
  }
  if (st.state === 'connecting') return 'Подключение… · код ' + code;
  return 'Нет связи · код ' + code;
}

function renderDrawer() {
  const a = window.app; if (!a.ui) return;
  setRow(a.ui.syncRow, '☁️', Store.state.userName || 'Общая карта', syncLabel());
  setRow(a.ui.tileRow, '🗺️', 'Тип карты', a.tile === 'osm' ? 'OpenStreetMap (схема)' : 'Esri (спутник)');
  setRow(a.ui.labelRow, '🏷️', 'Подписи маркеров', a.labels ? 'включены (с масштаба ≈ 14)' : 'выключены');

  const list = a.ui.list; list.textContent = '';
  const folders = Store.live('folders'), markers = Store.live('markers'), lines = Store.live('lines');
  const fname = (id) => { const f = Store.get('folders', id); return f && !f.deleted ? f.name : 'Без папки'; };

  if (a.query) {
    const q = a.query;
    const res = [];
    markers.forEach((m) => { if ((m.name || '').toLowerCase().includes(q)) res.push({ t: 'm', it: m }); });
    lines.forEach((l) => { if ((l.name || '').toLowerCase().includes(q)) res.push({ t: 'l', it: l }); });
    if (!res.length) { list.append(el('div', { class: 'empty' }, 'Ничего не найдено')); return; }
    res.slice(0, 60).forEach((r) => {
      const color = r.it.color || Store.folderColor(r.it.folderId);
      const row = el('div', { class: 'row', onclick: () => {
        closeDrawer();
        if (r.t === 'm') a.map.flyTo([r.it.lat, r.it.lng], Math.max(a.map.getZoom(), 17), { duration: 0.6 });
        else a.map.fitBounds(L.latLngBounds(r.it.points), { padding: [50, 50], maxZoom: 18 });
      } },
        el('div', { class: 'ico' }, el('span', { class: r.t === 'm' ? 'pinico' : 'dot-c', style: `--c:${color}` })),
        el('div', { class: 'txt' }, el('div', { class: 'ttl' }, r.it.name || '(без названия)'), el('div', { class: 'sub' }, (r.t === 'l' ? 'Линия · ' : '') + fname(r.it.folderId))));
      list.append(row);
    });
    if (res.length > 60) list.append(el('div', { class: 'empty' }, `Показаны первые 60 из ${res.length}`));
    return;
  }

  const total = el('div', { class: 'row', onclick: () => { closeDrawer(); fitTo(null); } },
    el('div', { class: 'ico' }, '⛶'),
    el('div', { class: 'txt' }, el('div', { class: 'ttl' }, 'Все'),
      el('div', { class: 'sub' }, `${markers.length} ${plural(markers.length, ['маркер', 'маркера', 'маркеров'])} в ${folders.length} ${plural(folders.length, ['папке', 'папках', 'папках'])}`)));
  list.append(total);

  folders.forEach((f) => {
    const mc = markers.filter((m) => m.folderId === f.id).length;
    const lc = lines.filter((l) => l.folderId === f.id).length;
    const hidden = Store.isHidden(f.id);
    const sub = `${mc} ${plural(mc, ['маркер', 'маркера', 'маркеров'])}` + (lc ? `, ${lc} ${plural(lc, ['линия', 'линии', 'линий'])}` : '');
    const row = el('div', {
      class: 'row' + (f.id === Store.state.activeFolderId ? ' active' : ''), style: hidden ? 'opacity:.55' : '',
      onclick: () => { Store.setActive(f.id); closeDrawer(); fitTo(f.id); toast('Активная папка: ' + f.name); },
    },
      el('div', { class: 'ico' }, el('span', { class: 'pinico', style: `--c:${f.color || Store.PALETTE[0]}` })),
      el('div', { class: 'txt' }, el('div', { class: 'ttl' }, f.name), el('div', { class: 'sub' }, sub)),
      el('button', { class: 'mini', title: 'Показать/скрыть', onclick: (e) => { e.stopPropagation(); Store.setHidden(f.id, !hidden); } }, hidden ? '🚫' : '👁'),
      el('button', { class: 'mini', title: 'Папка', onclick: (e) => { e.stopPropagation(); closeDrawer(); editFolder(f.id); } }, '⋮'));
    list.append(row);
  });
  list.append(el('button', { class: 'btn add-folder', onclick: () => { closeDrawer(); editFolder({ name: '', color: Store.PALETTE[folders.length % Store.PALETTE.length] }); } }, '＋ Новая папка'));
}

// ---------- нижний лист ----------
function openSheet(kind, ...content) {
  const a = window.app, box = $('sheetBox');
  box.textContent = ''; box.append(...content.flat().filter(Boolean));
  $('sheet').classList.remove('hidden');
  a.sheetKind = kind;
}
function closeSheet() { $('sheet').classList.add('hidden'); window.app.sheetKind = null; }

function colorPicker(initial, folderColor, onChange) {
  let cur = initial;
  const wrap = el('div', { class: 'swatches' });
  const btns = [];
  const mark = () => btns.forEach((b) => b.classList.toggle('sel', b.dataset.c === (cur || '')));
  Store.PALETTE.forEach((c) => {
    const b = el('button', { type: 'button', class: 'sw', style: `background:${c}`, 'data-c': c, 'aria-label': c,
      onclick: () => { cur = c; mark(); onChange(c); } });
    btns.push(b); wrap.append(b);
  });
  if (folderColor !== undefined) {
    const b = el('button', { type: 'button', class: 'chip', 'data-c': '', onclick: () => { cur = null; mark(); onChange(null); } }, 'как у папки');
    btns.push(b); wrap.append(b);
  }
  const custom = el('input', { type: 'color', value: initial || folderColor || '#22c55e', title: 'Свой цвет',
    onchange: (e) => { cur = Store.cleanColor(e.target.value); mark(); onChange(cur); } });
  wrap.append(custom);
  mark();
  return wrap;
}

function folderSelect(current, onChange) {
  const sel = el('select', { class: 'inp', onchange: (e) => onChange(e.target.value) },
    Store.live('folders').map((f) => el('option', { value: f.id, selected: f.id === current }, f.name)));
  return sel;
}

function confirmSheet(text, okLabel, onOk, back) {
  const prev = window.app.sheetKind;
  openSheet('confirm', el('h3', null, text),
    el('div', { class: 'btn-row' },
      el('button', { class: 'btn', onclick: () => { if (back) back(); else closeSheet(); } }, 'Отмена'),
      el('button', { class: 'btn danger', onclick: () => { closeSheet(); onOk(); } }, okLabel)));
}

function pickPhoto(onDone) {
  const inp = $('photoInput');
  inp.value = '';
  inp.onchange = () => {
    const f = inp.files && inp.files[0]; if (!f) return;
    compressImage(f, 300, 0.7).then(onDone).catch((err) => logErr('photo: ' + (err && err.message || err)));
  };
  inp.click();
}

// --- маркер ---
function editMarker(ref) {
  const isNew = typeof ref !== 'string';
  const base = isNew ? ref : Store.get('markers', ref);
  if (!base || base.deleted) return;
  const d = Object.assign({}, base);
  const nameIn = el('input', { type: 'text', class: 'inp', placeholder: 'Название', maxlength: 100, value: d.name || '' });
  const prev = el('img', { class: 'photo-prev', alt: 'фото' });
  const setPrev = () => { if (d.photo) { prev.src = d.photo; prev.style.display = ''; } else prev.style.display = 'none'; };
  setPrev();
  const folderColor = Store.folderColor(d.folderId);

  openSheet('marker',
    el('h3', null, isNew ? 'Новый маркер' : 'Маркер'),
    nameIn,
    el('div', { class: 'lbl' }, 'Папка'), folderSelect(d.folderId, (v) => { d.folderId = v; }),
    el('div', { class: 'lbl' }, 'Цвет'), colorPicker(d.color, folderColor, (c) => { d.color = c; }),
    el('div', { class: 'lbl' }, 'Фото'), prev,
    el('div', { class: 'btn-row' },
      el('button', { class: 'btn', id: '_photoBtn', onclick: () => pickPhoto((src) => { d.photo = src; setPrev(); }) }, '📷 Добавить/сменить'),
      el('button', { class: 'btn', id: '_photoClr', onclick: () => { d.photo = null; setPrev(); } }, 'Убрать')),
    el('div', { class: 'btn-row' },
      el('button', { class: 'btn', id: 'cancelBtn', onclick: closeSheet }, 'Отмена'),
      el('button', { class: 'btn primary', id: 'saveBtn', onclick: () => {
        d.name = nameIn.value.trim();
        if (isNew) d.id = Store.uid();
        Store.upsert('markers', d); closeSheet();
      } }, 'Сохранить')),
    isNew ? null : el('button', { class: 'btn', id: 'zoomBtn', onclick: () => { closeSheet(); window.app.map.flyTo([d.lat, d.lng], Math.max(window.app.map.getZoom(), 17)); } }, '🎯 Показать на карте'),
    isNew ? null : el('button', { class: 'btn danger', id: 'deleteBtn', onclick: () =>
      confirmSheet('Удалить этот маркер?', 'Удалить', () => Store.remove('markers', d.id), () => editMarker(d.id)) }, '🗑 Удалить'));
  if (isNew) setTimeout(() => nameIn.focus(), 50);
}

// --- линия ---
function editLine(ref) {
  const isNew = typeof ref !== 'string';
  const base = isNew ? ref : Store.get('lines', ref);
  if (!base || base.deleted) return;
  const d = Object.assign({}, base);
  const nameIn = el('input', { type: 'text', class: 'inp', placeholder: 'Название', maxlength: 100, value: d.name || '' });
  openSheet('line',
    el('h3', null, (isNew ? 'Новая линия' : 'Линия') + ' · ' + formatLen(lineLength(d.points))),
    nameIn,
    el('div', { class: 'lbl' }, 'Папка'), folderSelect(d.folderId, (v) => { d.folderId = v; }),
    el('div', { class: 'lbl' }, 'Цвет'), colorPicker(d.color, Store.folderColor(d.folderId), (c) => { d.color = c; }),
    el('div', { class: 'btn-row' },
      el('button', { class: 'btn', id: 'cancelBtn', onclick: closeSheet }, 'Отмена'),
      el('button', { class: 'btn primary', id: 'saveBtn', onclick: () => {
        d.name = nameIn.value.trim();
        if (isNew) d.id = Store.uid();
        Store.upsert('lines', d); closeSheet();
        if (isNew) toggleMeasureMode(false);
      } }, 'Сохранить')),
    isNew ? null : el('button', { class: 'btn danger', id: 'deleteBtn', onclick: () =>
      confirmSheet('Удалить эту линию?', 'Удалить', () => Store.remove('lines', d.id), () => editLine(d.id)) }, '🗑 Удалить'));
}

// --- папка ---
function editFolder(ref) {
  const isNew = typeof ref !== 'string';
  const base = isNew ? ref : Store.get('folders', ref);
  if (!base || base.deleted) return;
  const d = Object.assign({}, base);
  const nameIn = el('input', { type: 'text', class: 'inp', placeholder: 'Название папки', maxlength: 100, value: d.name || '' });
  const n = isNew ? 0 : allPoints(d.id).length;
  openSheet('folder',
    el('h3', null, isNew ? 'Новая папка' : 'Папка'),
    nameIn,
    el('div', { class: 'lbl' }, 'Цвет'), colorPicker(d.color, undefined, (c) => { d.color = c; }),
    el('div', { class: 'btn-row' },
      el('button', { class: 'btn', id: 'cancelBtn', onclick: closeSheet }, 'Отмена'),
      el('button', { class: 'btn primary', id: 'saveBtn', onclick: () => {
        d.name = nameIn.value.trim() || 'Папка';
        if (isNew) { d.id = Store.uid(); }
        Store.upsert('folders', d);
        if (isNew) Store.setActive(d.id);
        closeSheet();
      } }, 'Сохранить')),
    isNew ? null : el('button', { class: 'btn danger', id: 'deleteBtn', onclick: () =>
      confirmSheet(n ? `Удалить папку и всё внутри (${n})?` : 'Удалить папку?', 'Удалить', () => Store.deleteFolder(d.id), () => editFolder(d.id)) }, '🗑 Удалить папку'));
}

// --- синхронизация ---
function openSyncSheet() {
  const st = Sync.status(), id = Store.state.mapId;
  const nameIn = el('input', { type: 'text', class: 'inp', placeholder: 'Ваше имя (видят остальные)', maxlength: 40, value: Store.state.userName || '',
    onchange: (e) => Store.setUserName(e.target.value.trim()) });
  const parts = [el('h3', null, 'Общая карта'), el('div', { class: 'lbl' }, 'Ваше имя'), nameIn];

  if (!Sync.configured()) {
    parts.push(el('div', { class: 'note' }, 'Синхронизация не настроена. Создайте бесплатный проект Firebase и впишите его настройки в js/firebase-config.js — шаги в файле README. Пока карта работает только на этом телефоне.'));
  } else if (id) {
    parts.push(
      el('div', { class: 'lbl' }, 'Код карты — отправьте его участникам'),
      el('div', { class: 'code', id: 'mapCode' }, Sync.pretty(id)),
      el('div', { class: 'note' }, st.state === 'online' ? 'Подключено, изменения синхронизируются.' : st.state === 'connecting' ? 'Подключение…' : 'Нет связи' + (st.msg ? ': ' + st.msg : '') + '. Изменения сохраняются и отправятся при появлении сети.'),
      el('button', { class: 'btn', id: 'copyBtn', onclick: () => {
        try { navigator.clipboard.writeText(Sync.pretty(id)); toast('Код скопирован'); } catch (_) { toast('Выделите код и скопируйте вручную'); }
      } }, '📋 Скопировать код'),
      el('button', { class: 'btn danger', id: 'leaveBtn', onclick: async () => { await Sync.leave(); closeSheet(); toast('Отключено. Данные остались на телефоне'); } }, 'Отключиться от карты'));
  } else {
    const codeIn = el('input', { type: 'text', class: 'inp', id: 'codeInput', placeholder: 'Код карты, например K7P2M-9QXWD', maxlength: 14, autocapitalize: 'characters' });
    const err = el('div', { class: 'note', id: 'syncErr', style: 'color:#ff8b8b' });
    const run = async (fn) => { err.textContent = ''; try { await fn(); } catch (e) { err.textContent = e && e.message || String(e); } };
    parts.push(
      el('button', { class: 'btn primary', id: 'createBtn', onclick: () => run(async () => { Store.setUserName(nameIn.value.trim()); await Sync.create(); }) }, 'Создать общую карту из моих данных'),
      el('div', { class: 'lbl' }, 'или подключиться к чужой карте'),
      codeIn,
      el('button', { class: 'btn', id: 'joinBtn', onclick: () => run(async () => { Store.setUserName(nameIn.value.trim()); await Sync.join(codeIn.value); }) }, 'Подключиться по коду'),
      err,
      el('div', { class: 'note' }, 'При подключении ваши объекты добавятся к общей карте, объекты других участников появятся у вас.'));
  }
  parts.push(el('button', { class: 'btn', id: 'closeBtn', onclick: closeSheet }, 'Закрыть'));
  openSheet('sync', ...parts);
}

// ---------- режим добавления маркера ----------
let _addMenuEl = null;
function setAddMode(on) {
  const a = window.app;
  a.addMode = !!on;
  const cross = $('crosshair'); if (cross) cross.hidden = !a.addMode;
  const btn = $('fabAdd');
  btn.textContent = a.addMode ? '✔' : '＋';
  btn.onclick = a.addMode ? confirmAddAtCenter : toggleAddMenu;
}
function confirmAddAtCenter() {
  const c = window.app.map.getCenter();
  setAddMode(false);
  editMarker({ folderId: Store.state.activeFolderId, lat: c.lat, lng: c.lng, name: '', color: null, photo: null });
}

function baseAddItemCss() {
  return 'border:none;outline:none;cursor:pointer;background:rgba(32,34,40,.96);color:#f2f3f5;padding:12px 14px;border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.35);font-size:16px;min-width:150px;text-align:left;';
}
function ensureAddMenuUI() {
  if (_addMenuEl) return;
  const menu = el('div', { id: 'addMenu', style: 'position:fixed;right:80px;bottom:90px;display:none;flex-direction:column;gap:8px;z-index:510;' });
  menu.append(
    el('button', { class: 'add-item', id: 'addMarkerItem', style: baseAddItemCss(), onclick: () => { hideAddMenu(); if (measureState.active) toggleMeasureMode(false); setAddMode(true); } }, '📍 Маркер'),
    el('button', { class: 'add-item', id: 'addLineItem', style: baseAddItemCss(), onclick: () => { hideAddMenu(); if (window.app.addMode) setAddMode(false); toggleMeasureMode(true); } }, '📏 Линия'));
  document.body.appendChild(menu);
  _addMenuEl = menu;
  document.addEventListener('click', (e) => {
    if (!_addMenuEl || _addMenuEl.style.display === 'none') return;
    const btn = $('fabAdd');
    if (!(_addMenuEl.contains(e.target) || (btn && btn.contains(e.target)))) hideAddMenu();
  });
}
function toggleAddMenu() {
  ensureAddMenuUI();
  if (_addMenuEl.style.display === 'flex') hideAddMenu();
  else { _addMenuEl.style.display = 'flex'; $('fabAdd').textContent = '✖'; }
}
function hideAddMenu() {
  if (!_addMenuEl) return;
  _addMenuEl.style.display = 'none';
  $('fabAdd').textContent = window.app.addMode ? '✔' : '＋';
}

// ---------- режим линии / замера ----------
const measureState = { active: false, points: [], latlngs: [], poly: null, layer: null, bar: null };

function btnCss(color) {
  const base = 'border:none;padding:9px 11px;border-radius:10px;cursor:pointer;font-size:15px;';
  if (color === 'red') return base + 'background:rgba(239,68,68,.2);color:#ff8b8b;';
  if (color === 'blue') return base + 'background:#3b82f6;color:#fff;';
  return base + 'background:#3a3d47;color:#f2f3f5;';
}
function ensureMeasureUI() {
  if ($('measureBar')) return;
  const bar = el('div', { id: 'measureBar', style: 'position:fixed;left:50%;bottom:16px;transform:translateX(-50%);background:rgba(32,34,40,.97);color:#f2f3f5;border-radius:14px;box-shadow:0 8px 24px rgba(0,0,0,.4);padding:8px 10px;display:none;align-items:center;gap:8px;z-index:520;font-size:15px;' },
    el('span', { id: 'mTotal' }, '0 м'),
    el('button', { id: 'mAdd', style: btnCss(), onclick: () => addMeasurePoint('center') }, 'Точка'),
    el('button', { id: 'mUndo', style: btnCss(), onclick: undoMeasure }, 'Назад'),
    el('button', { id: 'mClear', style: btnCss('red'), onclick: clearMeasure }, 'Сброс'),
    el('button', { id: 'mDone', style: btnCss('blue'), onclick: finalizeMeasure }, 'Готово'));
  document.body.appendChild(bar);
  measureState.bar = bar;
}
function onMapClickMeasure(e) { addMeasurePoint(e.latlng); }
function toggleMeasureMode(on) {
  const a = window.app;
  if (on && !measureState.active) {
    measureState.active = true;
    if (!measureState.layer) measureState.layer = L.layerGroup().addTo(a.map);
    measureState.bar.style.display = 'flex';
    a.map.on('click', onMapClickMeasure);
    addMeasurePoint('center');
  } else if (!on) {
    a.map.off('click', onMapClickMeasure);
    measureState.active = false;
    measureState.bar.style.display = 'none';
    clearMeasure();
  }
}
function addMeasurePoint(src) {
  const a = window.app;
  const ll = src === 'center' ? a.map.getCenter() : src;
  const pt = L.circleMarker(ll, { radius: 7, color: '#111', weight: 2, fillColor: '#4ade80', fillOpacity: 0.95 });
  const drag = L.marker(ll, { draggable: true, opacity: 0, interactive: true });
  drag.on('drag', (ev) => { pt.setLatLng(ev.target.getLatLng()); redrawMeasure(); });
  drag.on('dragend', redrawMeasure);
  if (!measureState.layer) measureState.layer = L.layerGroup().addTo(a.map);
  measureState.layer.addLayer(pt); measureState.layer.addLayer(drag);
  measureState.points.push({ pt, drag });
  redrawMeasure();
}
function undoMeasure() {
  const last = measureState.points.pop();
  if (last) { measureState.layer.removeLayer(last.pt); measureState.layer.removeLayer(last.drag); redrawMeasure(); }
}
function clearMeasure() {
  if (measureState.poly) { measureState.layer.removeLayer(measureState.poly); measureState.poly = null; }
  measureState.points.forEach((p) => { measureState.layer.removeLayer(p.pt); measureState.layer.removeLayer(p.drag); });
  measureState.points = []; measureState.latlngs = [];
  updateMeasureTotal(0);
}
function redrawMeasure() {
  const lls = measureState.points.map((p) => p.pt.getLatLng());
  measureState.latlngs = lls;
  if (measureState.poly) measureState.poly.setLatLngs(lls);
  else if (lls.length) measureState.poly = L.polyline(lls, { color: '#22c55e', weight: 4 }).addTo(measureState.layer);
  updateMeasureTotal(lineLength(lls.map((l) => [l.lat, l.lng])));
}
function updateMeasureTotal(m) { const s = $('mTotal'); if (s) s.textContent = formatLen(m); }
function finalizeMeasure() {
  if (measureState.latlngs.length < 2) { toggleMeasureMode(false); return; }
  editLine({ folderId: Store.state.activeFolderId, name: 'Линия', color: null, points: measureState.latlngs.map((l) => [l.lat, l.lng]) });
}

// ---------- KML ----------
function exportKml() {
  try {
    const xml = Kml.build({ folders: Store.live('folders'), markers: Store.live('markers'), lines: Store.live('lines') });
    const name = 'fieldmap_' + new Date().toISOString().slice(0, 10) + '.kml';
    const mime = 'application/vnd.google-earth.kml+xml';
    if (window.AndroidBridge && AndroidBridge.shareFile) { AndroidBridge.shareFile(name, mime, xml); }
    else {
      const url = URL.createObjectURL(new Blob([xml], { type: mime }));
      const a = el('a', { href: url, download: name }); document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    }
    closeDrawer();
    toast('Экспорт: ' + name);
  } catch (e) { logErr('exportKml: ' + (e && e.message || e)); toast('Не удалось экспортировать'); }
}

function readFileText(file) {
  if (file.text) return file.text();
  return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsText(file); });
}
async function onImportFile() {
  const inp = $('importInput'), f = inp.files && inp.files[0];
  if (!f) return;
  try {
    const parsed = Kml.parse(await readFileText(f));
    if (!parsed.length) { toast('В файле нет точек и линий'); return; }
    let nm = 0, nl = 0;
    parsed.forEach((pf) => {
      let folder = Store.live('folders').find((x) => x.name === pf.name);
      if (!folder) {
        folder = { id: Store.uid(), name: pf.name, color: Store.PALETTE[Store.live('folders').length % Store.PALETTE.length] };
        Store.upsert('folders', folder);
      }
      pf.markers.forEach((m) => { if (Store.upsert('markers', { id: Store.uid(), folderId: folder.id, lat: m.lat, lng: m.lng, name: m.name, color: m.color })) nm++; });
      pf.lines.forEach((l) => { if (Store.upsert('lines', { id: Store.uid(), folderId: folder.id, name: l.name, color: l.color, points: l.points })) nl++; });
    });
    toast(`Импортировано: ${nm} ${plural(nm, ['маркер', 'маркера', 'маркеров'])}, ${nl} ${plural(nl, ['линия', 'линии', 'линий'])}`);
    const pts = allPoints(); if (pts.length) window.app.map.fitBounds(L.latLngBounds(pts), { padding: [40, 40], maxZoom: 17 });
  } catch (e) { console.warn('import: ' + (e && e.message || e)); toast('Ошибка импорта: ' + (e && e.message || e)); }
  finally { inp.value = ''; }
}

// ---------- кнопка «Назад» в Android ----------
// MainActivity вызывает эту функцию: true — мы закрыли что-то своё, false — можно выходить
window.__onBack = function () {
  const a = window.app;
  if (a.sheetKind) { closeSheet(); return true; }
  if (drawerOpen()) { closeDrawer(); return true; }
  if (_addMenuEl && _addMenuEl.style.display === 'flex') { hideAddMenu(); return true; }
  if (a.addMode) { setAddMode(false); return true; }
  if (measureState.active) { toggleMeasureMode(false); return true; }
  return false;
};
