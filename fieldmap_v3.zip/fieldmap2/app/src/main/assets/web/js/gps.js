// GPS — всегда включён; кнопка 📡 лишь центрирует карту на текущую позиции
(function () {
  const state = {
    watchId: null,
    marker: null,        // синяя точка
    accuracy: null,    // круг точности
    lastLatLng: null,  // последняя позиция
    started: false,
    errorNotified: false,
  };

  const getMap = () => (window.app && window.app.map) ? window.app.map : null;

  // === публичная функция для кнопки 📡 ===
  // Никаких включений/выключений — просто найти меня сейчас.
  window.toggleGPSCore = function () {
    const map = getMap();
    if (!map) return;

    if (state.lastLatLng) {
      // центрируемся без изменения большого масштаба
      const zoom = Math.max(map.getZoom(), 16);
      map.flyTo(state.lastLatLng, zoom, { animate: true, duration: 0.5 });
    } else {
      // если ещё нет фикса — попробуем однократно запросить и сразу центрироваться
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const ll = L.latLng(pos.coords.latitude, pos.coords.longitude);
          state.lastLatLng = ll;
          ensureGraphics(map);
          drawAt(ll, pos.coords.accuracy);
          map.flyTo(ll, 16, { animate: true, duration: 0.5 });
        },
        onError,
        { enableHighAccuracy: true, maximumAge: 0, timeout: 10000 }
      );
    }
  };

  // === авто-старт слежения (без автоподстройки карты) ===
  function startWatch() {
    if (state.started) return;
    if (!('geolocation' in navigator)) {
      if (!state.errorNotified) alert('Геолокация не поддерживается на этом устройстве');
      state.errorNotified = true;
      return;
    }
    state.started = true;

    state.watchId = navigator.geolocation.watchPosition(
      onPosition,
      onError,
      {
        enableHighAccuracy: true,
        maximumAge: 2000,
        timeout: 15000
      }
    );
  }

  function onPosition(pos) {
    const map = getMap();
    if (!map) return;
    const ll = L.latLng(pos.coords.latitude, pos.coords.longitude);
    state.lastLatLng = ll;

    ensureGraphics(map);
    drawAt(ll, pos.coords.accuracy);
    // ВАЖНО: не двигаем камеру здесь — пользователь свободно крутит карту.
  }

  function onError(err) {
    // не спамим: показываем один раз
    if (!state.errorNotified) {
      alert('Не удалось получить геопозицию: ' + (err?.message || err));
      state.errorNotified = true;
    }
    console.warn('GPS error:', err);
  }

  function ensureGraphics(map) {
    if (!state.accuracy) {
      state.accuracy = L.circle([0,0], {
        radius: 0,
        color: '#3b82f6',
        weight: 1,
        fillOpacity: 0.12
      }).addTo(map);
    }
    if (!state.marker) {
      state.marker = L.circleMarker([0,0], {
        radius: 7,
        color: '#2b6cb0',
        weight: 2,
        fillColor: '#3b82f6',
        fillOpacity: 0.9
      }).addTo(map);
    }
  }

  function drawAt(ll, accuracy) {
    if (state.marker) state.marker.setLatLng(ll);
    if (state.accuracy) {
      state.accuracy.setLatLng(ll);
      state.accuracy.setRadius(Math.max(5, accuracy || 30));
    }
  }

  // ждём, когда карта инициализируется, и запускаем watch
  function waitForMapAndStart() {
    const tick = setInterval(() => {
      const map = getMap();
      if (map) {
        clearInterval(tick);
        startWatch();
      }
    }, 150);
    // подстраховка: через 15с перестать ждать
    setTimeout(() => clearInterval(tick), 15000);
  }

  // очистка при закрытии страницы
  window.addEventListener('pagehide', () => {
    if (state.watchId != null) {
      try { navigator.geolocation.clearWatch(state.watchId); } catch(e){}
      state.watchId = null;
    }
  });

  // автозапуск
  waitForMapAndStart();
})(); 