// ===== KML: экспорт и импорт =====
// Экспорт: папки и подпапки -> вложенные <Folder>, маркеры -> Point, линии -> LineString, цвета через <Style>.
// Значок маркера и тип линии сохраняются в ExtendedData (их понимает только FieldMap). Фото в KML не входят.
// Импорт: Folder/Document (с вложенностью), Placemark (Point, LineString, Polygon, MultiGeometry), цвета из Style/StyleMap.
const Kml = (function () {
  const esc = (v) => String(v).replace(/[<>&"']/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c]));
  const toKmlColor = (hex) => 'ff' + hex.slice(5, 7) + hex.slice(3, 5) + hex.slice(1, 3); // #rrggbb -> aabbggrr
  const fromKmlColor = (c) => {
    c = String(c || '').trim().toLowerCase();
    return /^[0-9a-f]{8}$/.test(c) ? '#' + c.slice(6, 8) + c.slice(4, 6) + c.slice(2, 4) : null;
  };
  const okColor = (c) => (typeof c === 'string' && /^#[0-9a-f]{6}$/i.test(c) ? c.toLowerCase() : null);

  function build(data) {
    const styles = new Set();
    const styleUrl = (hex) => { hex = okColor(hex) || '#22c55e'; styles.add(hex); return '<styleUrl>#c' + hex.slice(1) + '</styleUrl>'; };
    const ext = (pairs) => {
      const p = pairs.filter((x) => x[1]);
      return p.length ? '<ExtendedData>' + p.map(([k, v]) => '<Data name="' + k + '"><value>' + esc(v) + '</value></Data>').join('') + '</ExtendedData>' : '';
    };
    const desc = (it) => (it.description ? '<description>' + esc(it.description) + '</description>' : '');
    const ids = new Set(data.folders.map((f) => f.id));
    const out = [];
    function folder(f) {
      const fcolor = f.color || '#22c55e';
      out.push('<Folder><name>' + esc(f.name || '') + '</name>');
      data.markers.filter((m) => m.folderId === f.id).forEach((m) => {
        out.push('<Placemark><name>' + esc(m.name || '') + '</name>' + desc(m) + styleUrl(m.color || fcolor) +
          ext([['shape', m.shape && m.shape !== 'pin' ? m.shape : '']]) +
          '<Point><coordinates>' + m.lng + ',' + m.lat + ',0</coordinates></Point></Placemark>');
      });
      data.lines.filter((l) => l.folderId === f.id && l.points && l.points.length > 1).forEach((l) => {
        out.push('<Placemark><name>' + esc(l.name || '') + '</name>' + desc(l) + styleUrl(l.color || fcolor) +
          ext([['style', l.style && l.style !== 'solid' ? l.style : '']]) +
          '<LineString><tessellate>1</tessellate><coordinates>' +
          l.points.map((p) => p[1] + ',' + p[0] + ',0').join(' ') + '</coordinates></LineString></Placemark>');
      });
      data.folders.filter((c) => c.parentId === f.id && c.id !== f.id).forEach(folder);
      out.push('</Folder>');
    }
    // верхний уровень: без родителя или с несуществующим родителем
    data.folders.filter((f) => !f.parentId || !ids.has(f.parentId)).forEach(folder);
    const st = [...styles].map((hex) => '<Style id="c' + hex.slice(1) + '"><IconStyle><color>' + toKmlColor(hex) +
      '</color></IconStyle><LineStyle><color>' + toKmlColor(hex) + '</color><width>4</width></LineStyle></Style>').join('');
    return '<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>FieldMap</name>' +
      st + out.join('') + '</Document></kml>';
  }

  const kids = (n, tag) => Array.from(n.children).filter((c) => c.localName === tag);
  const first = (n, tag) => kids(n, tag)[0] || null;
  const text = (n, tag) => { const c = first(n, tag); return c ? c.textContent.trim() : ''; };

  function coords(node) {
    return (node && node.textContent || '').trim().split(/\s+/).map((t) => {
      const p = t.split(',').map(Number);
      return [p[1], p[0]]; // [lat, lng]
    }).filter((p) => Number.isFinite(p[0]) && Number.isFinite(p[1]) && Math.abs(p[0]) <= 90 && Math.abs(p[1]) <= 180);
  }
  function extData(pm) {
    const o = {};
    const ed = first(pm, 'ExtendedData');
    if (ed) kids(ed, 'Data').forEach((d) => { o[d.getAttribute('name')] = text(d, 'value'); });
    return o;
  }

  // результат: плоский список папок { key, parentKey, name, markers[], lines[] } в порядке обхода
  function parse(textXml) {
    const doc = new DOMParser().parseFromString(textXml, 'application/xml');
    if (doc.getElementsByTagName('parsererror').length || !doc.documentElement) throw new Error('Файл не является корректным KML');

    const styleColor = {};
    Array.from(doc.getElementsByTagName('Style')).forEach((st) => {
      const id = st.getAttribute('id'); if (!id) return;
      const ic = first(st, 'IconStyle'), ls = first(st, 'LineStyle');
      const c = fromKmlColor(ic && text(ic, 'color')) || fromKmlColor(ls && text(ls, 'color'));
      if (c) styleColor[id] = c;
    });
    Array.from(doc.getElementsByTagName('StyleMap')).forEach((sm) => {
      const id = sm.getAttribute('id'); if (!id) return;
      const pair = kids(sm, 'Pair').find((p) => text(p, 'key') === 'normal');
      const url = pair && text(pair, 'styleUrl').replace('#', '');
      if (url && styleColor[url]) styleColor[id] = styleColor[url];
    });
    const colorOf = (pm) => {
      const inline = first(pm, 'Style');
      if (inline) {
        const ic = first(inline, 'IconStyle'), ls = first(inline, 'LineStyle');
        const c = fromKmlColor(ic && text(ic, 'color')) || fromKmlColor(ls && text(ls, 'color'));
        if (c) return c;
      }
      return styleColor[text(pm, 'styleUrl').replace('#', '')] || null;
    };

    const folders = [];
    let n = 0;
    const mk = (name, parentKey) => { const f = { key: 'k' + (n++), parentKey, name: name || 'Импорт', markers: [], lines: [] }; folders.push(f); return f; };
    let rootBucket = null;
    const root = () => rootBucket || (rootBucket = mk('Импорт', null));

    function geometry(node, f, base) {
      const tag = node.localName;
      if (tag === 'Point') {
        const c = coords(first(node, 'coordinates'));
        if (c[0]) f.markers.push(Object.assign({ lat: c[0][0], lng: c[0][1] }, base));
      } else if (tag === 'LineString' || tag === 'LinearRing') {
        const c = coords(first(node, 'coordinates'));
        if (c.length > 1) f.lines.push(Object.assign({ points: c }, base));
      } else if (tag === 'Polygon') {
        const outer = first(node, 'outerBoundaryIs'); const ring = outer && first(outer, 'LinearRing');
        const c = coords(ring && first(ring, 'coordinates'));
        if (c.length > 1) f.lines.push(Object.assign({ points: c }, base));
      } else if (tag === 'MultiGeometry') {
        Array.from(node.children).forEach((g) => geometry(g, f, base));
      }
    }

    // Document верхнего уровня папкой не считается; Folder (и вложенный Document) — папка
    function walk(node, f, isTop) {
      Array.from(node.children).forEach((ch) => {
        const t = ch.localName;
        if (t === 'Folder' || (t === 'Document' && !isTop)) walk(ch, mk(text(ch, 'name'), f ? f.key : null), false);
        else if (t === 'Document') walk(ch, f, false);
        else if (t === 'Placemark') {
          const ed = extData(ch);
          const base = { name: text(ch, 'name'), description: text(ch, 'description'), color: colorOf(ch) };
          if (ed.shape) base.shape = ed.shape;
          if (ed.style) base.style = ed.style;
          Array.from(ch.children).forEach((g) => {
            if (['Point', 'LineString', 'LinearRing', 'Polygon', 'MultiGeometry'].includes(g.localName)) geometry(g, f || root(), base);
          });
        }
      });
    }
    walk(doc.documentElement, null, true);
    // пустые папки без содержимого во всей ветке не нужны
    const has = (f) => f.markers.length || f.lines.length || folders.some((c) => c.parentKey === f.key && has(c));
    return folders.filter(has);
  }

  return { build, parse, okColor };
})();
