// ===== KML: экспорт и импорт =====
// Экспорт: папки -> <Folder>, маркеры -> Point, линии -> LineString, цвета через <Style>. Фото не экспортируются.
// Импорт: Folder/Document, Placemark (Point, LineString, Polygon, MultiGeometry), цвета из Style/StyleMap.
const Kml = (function () {
  const esc = (v) => String(v).replace(/[<>&"']/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c]));
  const toKmlColor = (hex) => 'ff' + hex.slice(5, 7) + hex.slice(3, 5) + hex.slice(1, 3); // #rrggbb -> aabbggrr
  const fromKmlColor = (c) => {
    c = String(c || '').trim().toLowerCase();
    return /^[0-9a-f]{8}$/.test(c) ? '#' + c.slice(6, 8) + c.slice(4, 6) + c.slice(2, 4) : null;
  };

  function build(data) {
    const styles = new Set();
    const styleId = (hex) => { const id = 'c' + hex.slice(1); styles.add(hex); return id; };
    const out = [];
    data.folders.forEach((f) => {
      const fcolor = f.color || '#22c55e';
      out.push('<Folder><name>' + esc(f.name) + '</name>');
      data.markers.filter((m) => m.folderId === f.id).forEach((m) => {
        out.push('<Placemark><name>' + esc(m.name) + '</name><styleUrl>#' + styleId(m.color || fcolor) +
          '</styleUrl><Point><coordinates>' + m.lng + ',' + m.lat + ',0</coordinates></Point></Placemark>');
      });
      data.lines.filter((l) => l.folderId === f.id).forEach((l) => {
        out.push('<Placemark><name>' + esc(l.name) + '</name><styleUrl>#' + styleId(l.color || fcolor) +
          '</styleUrl><LineString><tessellate>1</tessellate><coordinates>' +
          l.points.map((p) => p[1] + ',' + p[0] + ',0').join(' ') + '</coordinates></LineString></Placemark>');
      });
      out.push('</Folder>');
    });
    const st = [...styles].map((hex) => '<Style id="c' + hex.slice(1) + '"><IconStyle><color>' + toKmlColor(hex) +
      '</color></IconStyle><LineStyle><color>' + toKmlColor(hex) + '</color><width>4</width></LineStyle></Style>').join('');
    return '<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>FieldMap</name>' + st + out.join('') + '</Document></kml>';
  }

  const kids = (n, tag) => Array.from(n.children).filter((c) => c.localName === tag);
  const first = (n, tag) => kids(n, tag)[0] || null;
  const text = (n, tag) => { const c = first(n, tag); return c ? c.textContent.trim() : ''; };

  function coords(node) {
    return (node && node.textContent || '').trim().split(/\s+/).map((t) => {
      const p = t.split(',').map(Number);
      return [p[1], p[0]]; // [lat, lng]
    }).filter((p) => Number.isFinite(p[0]) && Number.isFinite(p[1]) && Math.abs(p[0]) <= 90 && Math.abs(p[1]) <= 180);
  }

  function parse(textXml) {
    const doc = new DOMParser().parseFromString(textXml, 'application/xml');
    if (doc.getElementsByTagName('parsererror').length || !doc.documentElement) throw new Error('Файл не является корректным KML');

    // стили: id -> цвет
    const styleColor = {};
    Array.from(doc.getElementsByTagName('Style')).forEach((st) => {
      const id = st.getAttribute('id'); if (!id) return;
      const ic = first(st, 'IconStyle'), ls = first(st, 'LineStyle');
      const c = fromKmlColor(ic && text(ic, 'color')) || fromKmlColor(ls && text(ls, 'color'));
      if (c) styleColor[id] = c;
    });
    Array.from(doc.getElementsByTagName('StyleMap')).forEach((sm) => {
      const id = sm.getAttribute('id'); if (!id) return;
      const pair = kids(sm, 'Pair').find((p) => text(p, 'key') === 'normal');
      const url = pair && text(pair, 'styleUrl').replace('#', '');
      if (url && styleColor[url]) styleColor[id] = styleColor[url];
    });
    const colorOf = (pm) => styleColor[text(pm, 'styleUrl').replace('#', '')] || null;

    const folders = new Map(); // имя -> {name, markers[], lines[]}
    const bucket = (name) => { name = name || 'Импорт'; if (!folders.has(name)) folders.set(name, { name, markers: [], lines: [] }); return folders.get(name); };

    function geometry(node, pm, name, color) {
      const tag = node.localName;
      if (tag === 'Point') {
        const c = coords(first(node, 'coordinates'));
        if (c[0]) bucket(pm.folder).markers.push({ name, lat: c[0][0], lng: c[0][1], color });
      } else if (tag === 'LineString') {
        const c = coords(first(node, 'coordinates'));
        if (c.length > 1) bucket(pm.folder).lines.push({ name, points: c, color });
      } else if (tag === 'Polygon') {
        const outer = first(node, 'outerBoundaryIs'); const ring = outer && first(outer, 'LinearRing');
        const c = coords(ring && first(ring, 'coordinates'));
        if (c.length > 1) bucket(pm.folder).lines.push({ name, points: c, color });
      } else if (tag === 'MultiGeometry') {
        Array.from(node.children).forEach((g) => geometry(g, pm, name, color));
      }
    }

    function walk(node, folderName) {
      Array.from(node.children).forEach((ch) => {
        const t = ch.localName;
        if (t === 'Folder' || t === 'Document') walk(ch, text(ch, 'name') || folderName);
        else if (t === 'Placemark') {
          const name = text(ch, 'name'), color = colorOf(ch);
          Array.from(ch.children).forEach((g) => {
            if (['Point', 'LineString', 'Polygon', 'MultiGeometry'].includes(g.localName)) geometry(g, { folder: folderName }, name, color);
          });
        }
      });
    }
    walk(doc.documentElement, '');
    return [...folders.values()].filter((f) => f.markers.length || f.lines.length);
  }

  return { build, parse };
})();
