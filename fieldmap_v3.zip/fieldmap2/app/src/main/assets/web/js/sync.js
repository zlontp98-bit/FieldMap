// ===== Аккаунт и общая карта: Firebase (вход через Google, Firestore) =====
// Вход: телефон показывает свои Google-аккаунты (MainActivity → Credential Manager), ID-токен приходит в страницу,
// Firebase входит по нему (signInWithCredential). Если телефон раньше входил анонимно (версии 3.x), Google-аккаунт
// привязывается к тому же uid (linkWithCredential) — ничего не теряется.
// Общая карта: один документ на объект — maps/{код}/items/{вид}_{id}, вид — folders, markers, lines, reels или photos.
// Побеждает более новое изменение (updatedAt). Удаление — пометка deleted:true.
// Фото — отдельные документы photos_{id} (одно фото на документ). Подписка их НЕ получает: фото скачивается,
// только когда его открывают (Store.photoGet → getPhoto). Участники карты — maps/{код}/members/{uid} = { name, role, joinedAt };
// владелец — первый, кто вошёл в карту (maps/{код}/info/owner создаётся один раз).
// Без настройки js/firebase-config.js приложение работает автономно.

// ---- Firebase SDK (подгружается с gstatic.com, нужен интернет) ----
let firebaseP = null;
function loadFirebase(cfg) {
  if (firebaseP) return firebaseP;
  const base = 'https://www.gstatic.com/firebasejs/10.14.1/';
  firebaseP = Promise.all([import(base + 'firebase-app.js'), import(base + 'firebase-auth.js'), import(base + 'firebase-firestore.js')])
    .then(([appM, authM, fsM]) => ({ app: appM.initializeApp(cfg), appM, authM, fsM }))
    .catch((e) => { firebaseP = null; throw e; });
  return firebaseP;
}

const SHARED_KINDS = ['folders', 'markers', 'lines', 'reels'];

// ---- Вход в Firebase ----
const FirebaseAuthBackend = {
  async create(cfg) {
    const fb = await loadFirebase(cfg);
    const A = fb.authM, auth = A.getAuth(fb.app);
    const info = (u) => {
      if (!u) return null;
      const g = (u.providerData || []).find((p) => p && p.providerId === 'google.com');
      return { uid: u.uid, google: !!g, name: u.displayName || (g && g.displayName) || '', email: u.email || (g && g.email) || '' };
    };
    return {
      onChange(cb) { A.onAuthStateChanged(auth, (u) => cb(info(u))); },
      async google(idToken) {
        const cred = A.GoogleAuthProvider.credential(idToken);
        const cur = auth.currentUser;
        if (cur && cur.isAnonymous) {
          try {
            const r = await A.linkWithCredential(cur, cred);
            await r.user.getIdToken(true);   // в новом токене уже есть Google — правила Firestore его увидят
            return info(r.user);
          } catch (e) {
            const c = String((e && e.code) || '');
            if (!c.includes('credential-already-in-use') && !c.includes('email-already-in-use')) throw e;
            // этот Google-аккаунт уже есть (например, приложение ставили заново) — просто входим в него
            const again = A.GoogleAuthProvider.credentialFromError(e) || cred;
            return info((await A.signInWithCredential(auth, again)).user);
          }
        }
        return info((await A.signInWithCredential(auth, cred)).user);
      },
      async signOut() { await A.signOut(auth); },
      async setName(name) { if (auth.currentUser) await A.updateProfile(auth.currentUser, { displayName: name }); },
    };
  },
};

// ---- Бэкенд Firestore ----
const FirestoreBackend = {
  async create(cfg) {
    const fb = await loadFirebase(cfg);
    const fsM = fb.fsM;
    let db;
    try { db = fsM.initializeFirestore(fb.app, { localCache: fsM.persistentLocalCache() }); } // офлайн-кэш
    catch (_) { db = fsM.getFirestore(fb.app); }
    const items = (mapId) => fsM.collection(db, 'maps', mapId, 'items');

    return {
      async subscribe(mapId, h) {
        const col = items(mapId);
        // всё, кроме фото: фото скачиваются по одному, когда их открывают
        const q = fsM.query(col, fsM.where('kind', 'in', SHARED_KINDS));
        const unsub = fsM.onSnapshot(q, { includeMetadataChanges: true }, (snap) => {
          const changes = [];
          snap.docChanges().forEach((c) => {
            if (c.type === 'removed') return;
            const d = c.doc.data();
            if (d && d.kind && d.id) changes.push({ kind: d.kind, id: d.id, data: d });
          });
          const fromCache = snap.metadata.fromCache;
          h.onChanges(changes, { fromCache });
          h.onState(!fromCache, fromCache ? 'Нет связи с сервером, изменения сохранятся' : '');
        }, (err) => h.onState(false, friendly(err)));
        return {
          push: (kind, id, data) => fsM.setDoc(fsM.doc(col, kind + '_' + id), data),
          close: unsub,
        };
      },
      async getPhoto(mapId, id) {
        const s = await fsM.getDoc(fsM.doc(items(mapId), 'photos_' + id));
        const d = s.exists() ? s.data() : null;
        return d && typeof d.data === 'string' ? d.data : null;
      },
      putPhoto: (mapId, id, data) => fsM.setDoc(fsM.doc(items(mapId), 'photos_' + id), { kind: 'photos', id, data, updatedAt: 1 }),
      // участник карты: запись о себе; владелец — тот, кто первым создал info/owner (правила не дают создать его второй раз)
      async joinMember(mapId, me) {
        const mref = fsM.doc(db, 'maps', mapId, 'members', me.uid);
        const oref = fsM.doc(db, 'maps', mapId, 'info', 'owner');
        let cur = null;
        try { cur = await fsM.getDoc(mref); } catch (e) { cur = null; }
        const was = cur && cur.exists() ? cur.data() : null;
        let role = was && was.role ? was.role : 'editor';
        if (!was) {
          try {
            const o = await fsM.getDoc(oref);
            if (!o.exists()) { await fsM.setDoc(oref, { uid: me.uid, at: Date.now() }); role = 'owner'; }
            else if (o.data().uid === me.uid) role = 'owner';
          } catch (e) { role = 'editor'; }
        }
        await fsM.setDoc(mref, { uid: me.uid, name: me.name || '', role, joinedAt: (was && was.joinedAt) || Date.now(), seenAt: Date.now() });
        return role;
      },
      async members(mapId) {
        const s = await fsM.getDocs(fsM.collection(db, 'maps', mapId, 'members'));
        const out = [];
        s.forEach((d) => { const v = d.data(); if (v) out.push(Object.assign({ uid: d.id }, v)); });
        return out;
      },
    };
  },
};

function friendly(err) {
  const c = (err && err.code) || '';
  if (c.includes('operation-not-allowed') || c.includes('admin-restricted')) return 'В Firebase не включён вход через Google (Authentication → Sign-in method → Google)';
  if (c.includes('permission-denied')) return 'Нет доступа: проверьте правила Firestore (firestore.rules)';
  if (c.includes('network') || c.includes('unavailable')) return 'Нет сети';
  if (c.includes('api-key') || c.includes('invalid-api-key')) return 'Неверный ключ Firebase в js/firebase-config.js';
  if (c.includes('invalid-credential')) return 'Google не подтвердил вход: проверьте Web client ID и SHA-1 в Firebase';
  return (err && err.message) || String(err);
}

// ---- Аккаунт: вход через Google ----
// user: { uid, google, name, email } или null. Последний вошедший запоминается на телефоне (имя видно и без интернета).
const Auth = (function () {
  const LS = 'fieldmap_account';
  const subs = [];
  let backend = null, user = null, ready = false, starting = null;
  try { const v = JSON.parse(localStorage.getItem(LS)); if (v && v.uid) user = v; } catch (e) { /* ignore */ }
  const cfg = () => window.FIREBASE_CONFIG || null;
  function configured() {
    if (window.FIELDMAP_AUTH_FACTORY) return true;
    const c = cfg();
    return !!(c && c.apiKey && c.projectId && !/YOUR_/.test(c.apiKey + c.projectId));
  }
  function save() { try { if (user) localStorage.setItem(LS, JSON.stringify(user)); else localStorage.removeItem(LS); } catch (e) { /* ignore */ } }
  function emit() { subs.forEach((f) => { try { f(user); } catch (e) { console.error(e); } }); }
  function set(u) {
    // своё имя (спросили один раз) главнее имени из Google
    if (u && user && user.uid === u.uid && user.name) u = Object.assign({}, u, { name: user.name, named: user.named });
    user = u; save(); emit();
  }
  // подключение к Firebase (нужен интернет); без него остаётся последний вход, сохранённый на телефоне
  function start() {
    if (starting) return starting;
    if (!configured()) return Promise.resolve(null);
    starting = (async () => {
      backend = window.FIELDMAP_AUTH_FACTORY ? await window.FIELDMAP_AUTH_FACTORY() : await FirebaseAuthBackend.create(cfg());
      await new Promise((res) => {
        let first = true;
        backend.onChange((u) => {
          // не вошли (или только анонимно с прошлой версии) — помним анонимный uid, но аккаунтом его не считаем
          set(u && u.google ? u : (u ? { uid: u.uid, google: false } : null));
          ready = true;
          if (first) { first = false; res(); }
        });
      });
      return user;
    })().catch((e) => { starting = null; console.error('Вход: ' + friendly(e)); throw e; });
    return starting;
  }
  // нажали «Войти через Google»: телефон показывает свои аккаунты, ответ придёт в window.__onGoogleSignIn
  let pending = null;
  window.__onGoogleSignIn = (res) => {
    let r = res;
    if (typeof r === 'string') { try { r = JSON.parse(r); } catch (e) { r = { error: r }; } }
    const p = pending; pending = null;
    if (p) p(r || { error: 'Вход отменён' });
  };
  async function signIn() {
    const B = window.AndroidBridge;
    if (!B || !B.googleSignIn) throw new Error('Вход через Google работает только в приложении на телефоне');
    const cid = window.GOOGLE_WEB_CLIENT_ID || '';
    if (!cid) throw new Error('Вход через Google ещё не настроен: нет Web client ID в js/firebase-config.js');
    await start();
    const r = await new Promise((res) => { pending = res; B.googleSignIn(cid); });
    if (!r || !r.idToken) throw new Error(r && r.error ? r.error : 'Вход отменён');
    const u = await backend.google(r.idToken);
    if (!u) throw new Error('Не удалось войти');
    set(Object.assign({}, u, { name: (user && user.uid === u.uid && user.name) || u.name || r.name || '', email: u.email || r.email || '', gname: r.name || u.name || '' }));
    return user;
  }
  async function signOut() {
    if (backend) await backend.signOut();
    set(null);
  }
  async function setName(name) {
    name = String(name || '').trim().slice(0, 60);
    if (!user || !name) return;
    user = Object.assign({}, user, { name, named: true }); save(); emit();
    try { if (backend) await backend.setName(name); } catch (e) { /* имя на телефоне уже сохранено */ }
  }
  window.addEventListener('online', () => { if (!ready) start().catch(() => {}); });
  return {
    configured, start, signIn, signOut, setName,
    get user() { return user; },
    get ready() { return ready; },
    google: () => !!(user && user.google),
    onChange(f) { subs.push(f); },
  };
})();

const Sync = (function () {
  const statusSubs = [], remoteSubs = [];
  let st = { state: 'off', msg: '' };
  let backend = null, conn = null, session = 0, role = null;
  const remoteIdx = new Map();   // "вид:id" -> updatedAt, известный на сервере
  const uploading = new Set();   // фото, которые сейчас отправляются
  const PHOTO_MAX = 900000;      // запас до лимита документа Firestore (1 МБ)

  const cfg = () => window.FIREBASE_CONFIG || null;
  function configured() {
    if (window.FIELDMAP_BACKEND_FACTORY) return true;
    const c = cfg();
    return !!(c && c.apiKey && c.projectId && !/YOUR_/.test(c.apiKey + c.projectId));
  }
  function setStatus(state, msg) {
    st = { state, msg: msg || '' };
    statusSubs.forEach((f) => { try { f(st); } catch (e) { console.error(e); } });
  }
  const norm = (code) => String(code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const pretty = (code) => (code && code.length === 10 ? code.slice(0, 5) + '-' + code.slice(5) : code || '');
  function newCode() {
    const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const r = new Uint8Array(10);
    if (window.crypto && crypto.getRandomValues) crypto.getRandomValues(r);
    else r.forEach((_, i) => { r[i] = Math.floor(Math.random() * 256); });
    return Array.from(r, (x) => A[x % A.length]).join('');
  }
  async function getBackend() {
    if (!backend) backend = window.FIELDMAP_BACKEND_FACTORY ? await window.FIELDMAP_BACKEND_FACTORY() : await FirestoreBackend.create(cfg());
    return backend;
  }

  // Firestore не принимает вложенные массивы (точки линий, слои кабелей), поэтому сам объект
  // передаётся строкой JSON в поле json; рядом — поля, по которым идёт синхронизация
  function toWire(kind, rec) {
    const o = { kind, id: rec.id, updatedAt: rec.updatedAt || 1, deleted: !!rec.deleted };
    if (!rec.deleted) {
      const body = Object.assign({}, rec);
      delete body.updatedAt; delete body.deleted;
      o.json = JSON.stringify(body);
    }
    return o;
  }
  function fromWire(data) {
    let body = {};
    if (typeof data.json === 'string') { try { body = JSON.parse(data.json) || {}; } catch (e) { body = {}; } }
    return Object.assign(body, { id: data.id, updatedAt: data.updatedAt, deleted: !!data.deleted });
  }

  // слишком большое фото пересжимаем, пока не поместится в документ
  function shrink(data) {
    if (data.length <= PHOTO_MAX) return Promise.resolve(data);
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        let side = Math.max(img.naturalWidth, img.naturalHeight), q = 0.7, out = data;
        for (let i = 0; i < 6 && out.length > PHOTO_MAX; i++) {
          side = Math.round(side * 0.8);
          const k = Math.min(1, side / Math.max(img.naturalWidth, img.naturalHeight));
          const c = document.createElement('canvas');
          c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          out = c.toDataURL('image/jpeg', q);
          q = Math.max(0.5, q - 0.05);
        }
        resolve(out.length <= PHOTO_MAX ? out : null);
      };
      img.onerror = () => resolve(null);
      img.src = data;
    });
  }

  function fail(e) { setStatus('offline', friendly(e)); }

  // фото с этого телефона, которого ещё нет на общей карте; чужое и ещё не скачанное отправит тот, кто снял
  async function uploadPhoto(id) {
    if (!conn || Store.isSent(id) || uploading.has(id)) return;
    uploading.add(id);
    const my = session, code = Store.mapId;
    try {
      const data = await Store.photoLocal(id);
      if (!data) return;
      const d = await shrink(data);
      if (!d || my !== session) return;
      await backend.putPhoto(code, id, d);
      if (my === session) Store.markSent(id);
    } catch (e) { fail(e); } finally { uploading.delete(id); }
  }
  const uploadPhotosOf = (rec) => { if (!rec.deleted) Store.photoIds(rec.photos).forEach(uploadPhoto); };

  function pushRec(kind, rec) {
    if (!conn) return;
    if (Store.WITH_PHOTOS.includes(kind)) uploadPhotosOf(rec);
    remoteIdx.set(kind + ':' + rec.id, rec.updatedAt);
    Promise.resolve(conn.push(kind, rec.id, toWire(kind, rec))).catch(fail);
  }

  // всё, чего нет на сервере или что новее серверной версии
  function pushLocalDiff() {
    Store.KINDS.forEach((kind) => {
      Store.allRecords(kind).forEach((rec) => {
        const r = remoteIdx.get(kind + ':' + rec.id);
        if (r == null ? !rec.deleted : rec.updatedAt > r) pushRec(kind, rec);
        else if (Store.WITH_PHOTOS.includes(kind)) uploadPhotosOf(rec);
      });
    });
  }

  function notifyRemote() { remoteSubs.forEach((f) => { try { f(); } catch (e) { console.error(e); } }); }

  function disconnectInternal() {
    session++;
    if (conn && conn.close) { try { conn.close(); } catch (_) {} }
    conn = null; role = null; remoteIdx.clear(); uploading.clear();
  }

  // запись о себе в участниках карты (имя видно всем; email туда не кладём)
  function joinMember(code) {
    const u = Auth.user;
    if (!u || !backend || !backend.joinMember) return;
    const my = session;
    backend.joinMember(code, { uid: u.uid, name: u.name || '' })
      .then((r) => { if (my === session) { role = r; setStatus(st.state, st.msg); } })
      .catch((e) => console.error('Участники: ' + friendly(e)));
  }

  // mode: 'create' — новая карта из моих данных; 'merge' — мои данные добавляются к общей карте;
  // 'replace' — на телефоне остаётся только общая карта; 'resume' — повторное подключение при запуске
  async function connect(code, mode) {
    code = norm(code);
    if (code.length !== 10) throw new Error('Код должен состоять из 10 символов (буквы и цифры)');
    if (!configured()) throw new Error('Firebase не настроен: заполните js/firebase-config.js');
    if (!Auth.google()) throw new Error('Войдите через Google — общая карта только для вошедших');
    disconnectInternal();
    const my = session;
    setStatus('connecting');
    let initialDone = false;
    try {
      await Auth.start();                     // Firestore пускает только вошедших: сначала вход
      if (!Auth.google()) throw new Error('Войдите через Google — общая карта только для вошедших');
      await getBackend();
      if (my !== session) return;
      const c = await backend.subscribe(code, {
        onChanges(changes, meta) {
          if (my !== session) return;
          let changed = false;
          changes.forEach((ch) => {
            if (!Store.KINDS.includes(ch.kind)) return;
            const rec = fromWire(Object.assign({}, ch.data, { id: ch.id }));
            const known = remoteIdx.get(ch.kind + ':' + ch.id) || 0;
            remoteIdx.set(ch.kind + ':' + ch.id, Math.max(known, Number(rec.updatedAt) || 0));
            if (Store.applyRemote(ch.kind, rec)) changed = true;
          });
          // локальные данные отправляем только после ответа самого сервера (не из кэша)
          if (!initialDone && !(meta && meta.fromCache)) {
            initialDone = true;
            const onServer = new Set(remoteIdx.keys());
            // подключение по коду к пустой карте — почти наверняка опечатка в коде: ничего не отправляем
            if ((mode === 'merge' || mode === 'replace') && !onServer.size) {
              disconnectInternal(); Store.setMapId(null);
              setStatus('off', 'Карта с таким кодом не найдена');
              return;
            }
            if (mode === 'replace') { Store.dropLocalOnly(onServer); changed = true; }
            if (changed) { notifyRemote(); changed = false; }
            pushLocalDiff();
            joinMember(code);
          }
          if (changed) notifyRemote();
        },
        onState(online, msg) { if (my === session) setStatus(online ? 'online' : 'offline', msg); },
      });
      if (my !== session) { if (c && c.close) c.close(); return; }
      conn = c;
      Store.setMapId(code);
      if (initialDone) { pushLocalDiff(); joinMember(code); }   // сервер ответил ещё до того, как подключение было готово
    } catch (e) {
      if (my === session) { disconnectInternal(); fail(e); }
      throw new Error(friendly(e));
    }
  }

  Store.on((evt) => { if (conn) pushRec(evt.kind, evt.rec); });
  // фото, которого нет на телефоне, скачиваем с общей карты, когда его открывают
  Store.setPhotoFetcher(async (id) => {
    const code = Store.mapId;
    if (!code || !configured() || !Auth.google()) return null;
    await Auth.start();
    const b = await getBackend();
    return b.getPhoto ? b.getPhoto(code, id) : null;
  });

  function autostart() {
    const id = Store.mapId;
    if (!id || !configured() || conn) return;
    if (!Auth.google()) { setStatus('off', 'Войдите через Google, чтобы работать с общей картой'); return; }
    connect(id, 'resume').catch((e) => console.error('Синхронизация: ' + friendly(e)));
  }
  // вошли — подключаемся к своей карте; вышли — отключаемся (код карты остаётся на телефоне)
  Auth.onChange((u) => {
    if (u && u.google) { if (!conn) autostart(); else if (Store.mapId) joinMember(Store.mapId); return; }
    if (conn) { disconnectInternal(); setStatus('off', Store.mapId ? 'Войдите через Google, чтобы работать с общей картой' : ''); }
  });

  window.addEventListener('online', () => { if (Store.mapId && !conn) autostart(); });

  return {
    configured, pretty, norm,
    status: () => st,
    connected: () => !!conn,
    role: () => role,
    onStatus(f) { statusSubs.push(f); },
    onRemote(f) { remoteSubs.push(f); },
    async create() { const code = newCode(); await connect(code, 'create'); return code; },
    join(code, mode) { return connect(code, mode === 'replace' ? 'replace' : 'merge'); },
    leave() { disconnectInternal(); Store.setMapId(null); setStatus('off'); },
    async members() {
      const code = Store.mapId;
      if (!code || !Auth.google()) return [];
      await Auth.start();
      const b = await getBackend();
      return b.members ? b.members(code) : [];
    },
    autostart,
  };
})();
