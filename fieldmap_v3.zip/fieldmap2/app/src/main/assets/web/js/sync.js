// ===== Общая карта: синхронизация через Firebase (Firestore) =====
// Один документ на объект: maps/{код}/items/{вид}_{id}, вид — folders, markers, lines, reels или photos.
// Побеждает более новое изменение (updatedAt). Удаление — пометка deleted:true.
// Фото — отдельные документы photos_{id} (одно фото на документ, чтобы не упереться в лимит 1 МБ),
// маркер хранит только список id своих фото.
// Без настройки js/firebase-config.js приложение работает автономно.

// ---- Бэкенд Firestore (SDK подгружается с gstatic.com, нужен интернет) ----
const FirestoreBackend = {
  async create(cfg) {
    const base = 'https://www.gstatic.com/firebasejs/10.14.1/';
    const [appM, authM, fsM] = await Promise.all([
      import(base + 'firebase-app.js'), import(base + 'firebase-auth.js'), import(base + 'firebase-firestore.js'),
    ]);
    const app = appM.initializeApp(cfg);
    await authM.signInAnonymously(authM.getAuth(app));
    let db;
    try { db = fsM.initializeFirestore(app, { localCache: fsM.persistentLocalCache() }); } // офлайн-кэш
    catch (_) { db = fsM.getFirestore(app); }

    return {
      async subscribe(mapId, h) {
        const col = fsM.collection(db, 'maps', mapId, 'items');
        const unsub = fsM.onSnapshot(col, { includeMetadataChanges: true }, (snap) => {
          const changes = [];
          snap.docChanges().forEach((c) => {
            if (c.type === 'removed') return;
            const d = c.doc.data();
            if (d && d.kind && d.id) changes.push({ kind: d.kind, id: d.id, data: d });
          });
          const fromCache = snap.metadata.fromCache;
          h.onChanges(changes, { fromCache });
          h.onState(!fromCache, fromCache ? 'Нет связи с сервером, изменения сохранятся' : '');
        }, (err) => h.onState(false, friendly(err)));
        return {
          push: (kind, id, data) => fsM.setDoc(fsM.doc(col, kind + '_' + id), data),
          close: unsub,
        };
      },
    };
  },
};

function friendly(err) {
  const c = (err && err.code) || '';
  if (c.includes('operation-not-allowed') || c.includes('admin-restricted')) return 'В Firebase не включён анонимный вход (Authentication → Sign-in method → Anonymous)';
  if (c.includes('permission-denied')) return 'Нет доступа: проверьте правила Firestore (firestore.rules)';
  if (c.includes('network') || c.includes('unavailable')) return 'Нет сети';
  if (c.includes('api-key') || c.includes('invalid-api-key')) return 'Неверный ключ Firebase в js/firebase-config.js';
  return (err && err.message) || String(err);
}

const Sync = (function () {
  const statusSubs = [], remoteSubs = [];
  let st = { state: 'off', msg: '' };
  let backend = null, conn = null, session = 0;
  const remoteIdx = new Map();   // "вид:id" -> updatedAt, известный на сервере
  const sentPhotos = new Set();  // фото, уже отправленные в этом подключении
  const PHOTO_MAX = 900000;      // запас до лимита документа Firestore (1 МБ)

  const cfg = () => window.FIREBASE_CONFIG || null;
  function configured() {
    if (window.FIELDMAP_BACKEND_FACTORY) return true;
    const c = cfg();
    return !!(c && c.apiKey && c.projectId && !/YOUR_/.test(c.apiKey + c.projectId));
  }
  function setStatus(state, msg) {
    st = { state, msg: msg || '' };
    statusSubs.forEach((f) => { try { f(st); } catch (e) { console.error(e); } });
  }
  const norm = (code) => String(code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const pretty = (code) => (code && code.length === 10 ? code.slice(0, 5) + '-' + code.slice(5) : code || '');
  function newCode() {
    const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const r = new Uint8Array(10);
    if (window.crypto && crypto.getRandomValues) crypto.getRandomValues(r);
    else r.forEach((_, i) => { r[i] = Math.floor(Math.random() * 256); });
    return Array.from(r, (x) => A[x % A.length]).join('');
  }

  // Firestore не принимает вложенные массивы (точки линий, слои кабелей), поэтому сам объект
  // передаётся строкой JSON в поле json; рядом — поля, по которым идёт синхронизация
  function toWire(kind, rec) {
    const o = { kind, id: rec.id, updatedAt: rec.updatedAt || 1, deleted: !!rec.deleted };
    if (!rec.deleted) {
      const body = Object.assign({}, rec);
      delete body.updatedAt; delete body.deleted;
      o.json = JSON.stringify(body);
    }
    return o;
  }
  function fromWire(data) {
    let body = {};
    if (typeof data.json === 'string') { try { body = JSON.parse(data.json) || {}; } catch (e) { body = {}; } }
    return Object.assign(body, { id: data.id, updatedAt: data.updatedAt, deleted: !!data.deleted });
  }

  // слишком большое фото пересжимаем, пока не поместится в документ
  function shrink(data) {
    if (data.length <= PHOTO_MAX) return Promise.resolve(data);
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        let side = Math.max(img.naturalWidth, img.naturalHeight), q = 0.7, out = data;
        for (let i = 0; i < 6 && out.length > PHOTO_MAX; i++) {
          side = Math.round(side * 0.8);
          const k = Math.min(1, side / Math.max(img.naturalWidth, img.naturalHeight));
          const c = document.createElement('canvas');
          c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          out = c.toDataURL('image/jpeg', q);
          q = Math.max(0.5, q - 0.05);
        }
        resolve(out.length <= PHOTO_MAX ? out : null);
      };
      img.onerror = () => resolve(null);
      img.src = data;
    });
  }

  function fail(e) { setStatus('offline', friendly(e)); }

  function pushPhoto(pid) {
    if (!conn || remoteIdx.has('photos:' + pid) || sentPhotos.has(pid)) return;
    const data = Store.getPhoto(pid);
    if (!data) return;                       // фото ещё не загружено с сервера — его отправит владелец
    sentPhotos.add(pid);
    const c = conn;
    shrink(data).then((d) => {
      if (!d) { sentPhotos.delete(pid); return; }
      return Promise.resolve(c.push('photos', pid, { kind: 'photos', id: pid, data: d, updatedAt: 1 }));
    }).catch((e) => { sentPhotos.delete(pid); fail(e); });
  }

  function pushRec(kind, rec) {
    if (!conn) return;
    if (kind === 'markers' && !rec.deleted) (rec.photos || []).forEach(pushPhoto);
    remoteIdx.set(kind + ':' + rec.id, rec.updatedAt);
    Promise.resolve(conn.push(kind, rec.id, toWire(kind, rec))).catch(fail);
  }

  // всё, чего нет на сервере или что новее серверной версии
  function pushLocalDiff() {
    Store.KINDS.forEach((kind) => {
      Store.allRecords(kind).forEach((rec) => {
        const r = remoteIdx.get(kind + ':' + rec.id);
        if (r == null ? !rec.deleted : rec.updatedAt > r) pushRec(kind, rec);
        else if (kind === 'markers' && !rec.deleted) (rec.photos || []).forEach(pushPhoto);
      });
    });
  }

  function notifyRemote() { remoteSubs.forEach((f) => { try { f(); } catch (e) { console.error(e); } }); }

  function disconnectInternal() {
    session++;
    if (conn && conn.close) { try { conn.close(); } catch (_) {} }
    conn = null; remoteIdx.clear(); sentPhotos.clear();
  }

  // mode: 'create' — новая карта из моих данных; 'merge' — мои данные добавляются к общей карте;
  // 'replace' — на телефоне остаётся только общая карта; 'resume' — повторное подключение при запуске
  async function connect(code, mode) {
    code = norm(code);
    if (code.length !== 10) throw new Error('Код должен состоять из 10 символов (буквы и цифры)');
    if (!configured()) throw new Error('Firebase не настроен: заполните js/firebase-config.js');
    disconnectInternal();
    const my = session;
    setStatus('connecting');
    let initialDone = false;
    try {
      if (!backend) backend = window.FIELDMAP_BACKEND_FACTORY ? await window.FIELDMAP_BACKEND_FACTORY() : await FirestoreBackend.create(cfg());
      if (my !== session) return;
      const c = await backend.subscribe(code, {
        onChanges(changes, meta) {
          if (my !== session) return;
          let changed = false;
          // сначала фото, чтобы маркеры из той же пачки сразу их получили
          changes.forEach((ch) => {
            if (ch.kind !== 'photos') return;
            remoteIdx.set('photos:' + ch.id, 1);
            Store.putPhoto(ch.id, ch.data && ch.data.data);
          });
          changes.forEach((ch) => {
            if (!Store.KINDS.includes(ch.kind)) return;
            const rec = fromWire(Object.assign({}, ch.data, { id: ch.id }));
            const known = remoteIdx.get(ch.kind + ':' + ch.id) || 0;
            remoteIdx.set(ch.kind + ':' + ch.id, Math.max(known, Number(rec.updatedAt) || 0));
            if (Store.applyRemote(ch.kind, rec)) changed = true;
          });
          // локальные данные отправляем только после ответа самого сервера (не из кэша)
          if (!initialDone && !(meta && meta.fromCache)) {
            initialDone = true;
            const onServer = new Set([...remoteIdx.keys()].filter((k) => !k.startsWith('photos:')));
            // подключение по коду к пустой карте — почти наверняка опечатка в коде: ничего не отправляем
            if ((mode === 'merge' || mode === 'replace') && !onServer.size) {
              disconnectInternal(); Store.setMapId(null);
              setStatus('off', 'Карта с таким кодом не найдена');
              return;
            }
            if (mode === 'replace') { Store.dropLocalOnly(onServer); changed = true; }
            if (changed) { notifyRemote(); changed = false; }
            pushLocalDiff();
          }
          if (changed) notifyRemote();
        },
        onState(online, msg) { if (my === session) setStatus(online ? 'online' : 'offline', msg); },
      });
      if (my !== session) { if (c && c.close) c.close(); return; }
      conn = c;
      Store.setMapId(code);
      if (initialDone) pushLocalDiff();       // сервер ответил ещё до того, как подключение было готово
    } catch (e) {
      if (my === session) { disconnectInternal(); fail(e); }
      throw new Error(friendly(e));
    }
  }

  Store.on((evt) => { if (conn) pushRec(evt.kind, evt.rec); });

  window.addEventListener('online', () => { if (Store.mapId && !conn) Sync.autostart(); });

  return {
    configured, pretty, norm,
    status: () => st,
    connected: () => !!conn,
    onStatus(f) { statusSubs.push(f); },
    onRemote(f) { remoteSubs.push(f); },
    async create() { const code = newCode(); await connect(code, 'create'); return code; },
    join(code, mode) { return connect(code, mode === 'replace' ? 'replace' : 'merge'); },
    leave() { disconnectInternal(); Store.setMapId(null); setStatus('off'); },
    autostart() {
      const id = Store.mapId;
      if (id && configured()) connect(id, 'resume').catch((e) => console.error('Синхронизация: ' + friendly(e)));
    },
  };
})();
