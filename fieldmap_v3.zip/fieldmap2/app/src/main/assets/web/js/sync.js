// ===== Общая карта: синхронизация через Firebase (Firestore) =====
// Один документ на объект: maps/{код}/items/{вид}_{id}. Побеждает более новое изменение (updatedAt).
// Без настройки js/firebase-config.js приложение работает автономно, как раньше.

// ---- Бэкенд Firestore (SDK подгружается с gstatic.com, нужен интернет) ----
const FirestoreBackend = {
  async create(cfg) {
    const base = 'https://www.gstatic.com/firebasejs/10.14.1/';
    const [appM, authM, fsM] = await Promise.all([
      import(base + 'firebase-app.js'), import(base + 'firebase-auth.js'), import(base + 'firebase-firestore.js'),
    ]);
    const app = appM.initializeApp(cfg);
    await authM.signInAnonymously(authM.getAuth(app));
    let db;
    try { db = fsM.initializeFirestore(app, { localCache: fsM.persistentLocalCache() }); } // офлайн-кэш
    catch (_) { db = fsM.getFirestore(app); }

    return {
      async subscribe(mapId, h) {
        const col = fsM.collection(db, 'maps', mapId, 'items');
        const unsub = fsM.onSnapshot(col, { includeMetadataChanges: true }, (snap) => {
          const changes = [];
          snap.docChanges().forEach((c) => {
            if (c.type === 'removed') return;
            const d = c.doc.data();
            if (d && d.kind && d.id) changes.push({ kind: d.kind, id: d.id, data: d });
          });
          const fromCache = snap.metadata.fromCache;
          h.onChanges(changes, { fromCache });
          h.onState(!fromCache, fromCache ? 'нет связи с сервером, изменения сохранятся' : '');
        }, (err) => h.onState(false, friendly(err)));
        return {
          push: (kind, id, data) => fsM.setDoc(fsM.doc(col, kind + '_' + id), data),
          close: unsub,
        };
      },
    };
  },
};

function friendly(err) {
  const c = (err && err.code) || '';
  if (c.includes('operation-not-allowed')) return 'в Firebase не включён анонимный вход (Authentication → Sign-in method → Anonymous)';
  if (c.includes('permission-denied')) return 'нет доступа: проверьте правила Firestore (firestore.rules)';
  if (c.includes('network')) return 'нет сети';
  return (err && err.message) || String(err);
}

const Sync = (function () {
  const subs = [];
  let st = { state: 'off', msg: '', last: null };
  let backend = null, conn = null;
  const remoteIdx = new Map(); // "вид:id" -> updatedAt, который известен на сервере

  const cfg = () => window.FIREBASE_CONFIG || null;
  function configured() {
    if (window.FIELDMAP_BACKEND_FACTORY) return true;
    const c = cfg();
    return !!(c && c.apiKey && c.projectId && !/YOUR_/.test(c.apiKey + c.projectId));
  }
  function setStatus(state, msg) {
    st = { state, msg: msg || '', last: state === 'online' ? Date.now() : st.last };
    subs.forEach((f) => { try { f(st); } catch (_) {} });
  }
  const norm = (code) => String(code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const pretty = (code) => (code && code.length === 10 ? code.slice(0, 5) + '-' + code.slice(5) : code || '');
  function newCode() {
    const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const r = new Uint8Array(10);
    (window.crypto || {}).getRandomValues ? crypto.getRandomValues(r) : r.forEach((_, i) => (r[i] = Math.floor(Math.random() * 256)));
    return Array.from(r, (x) => A[x % A.length]).join('');
  }

  // Firestore не принимает вложенные массивы -> точки линии передаём плоским списком
  function toWire(kind, item) {
    const o = JSON.parse(JSON.stringify(item));
    o.kind = kind;
    if (kind === 'lines') { o.pts = (item.points || []).flat(); delete o.points; }
    return o;
  }
  function fromWire(data) {
    const o = Object.assign({}, data);
    if (o.kind === 'lines') {
      const pts = [], flat = Array.isArray(o.pts) ? o.pts : [];
      for (let i = 0; i + 1 < flat.length; i += 2) pts.push([flat[i], flat[i + 1]]);
      o.points = pts; delete o.pts;
    }
    return o;
  }

  function pushOne(kind, item) {
    if (!conn) return;
    remoteIdx.set(kind + ':' + item.id, item.updatedAt);
    Promise.resolve(conn.push(kind, item.id, toWire(kind, item))).catch((e) => setStatus('offline', friendly(e)));
  }

  function pushLocalDiff() {
    ['folders', 'markers', 'lines'].forEach((kind) => {
      Store.state[kind].forEach((it) => {
        const r = remoteIdx.get(kind + ':' + it.id);
        if (r == null || it.updatedAt > r) pushOne(kind, it);
      });
    });
  }

  async function disconnectInternal() {
    if (conn && conn.close) { try { conn.close(); } catch (_) {} }
    conn = null; remoteIdx.clear();
  }

  async function connect(code) {
    code = norm(code);
    if (code.length !== 10) throw new Error('Код должен состоять из 10 символов (буквы и цифры)');
    if (!configured()) throw new Error('Firebase не настроен: заполните js/firebase-config.js');
    await disconnectInternal();
    setStatus('connecting');
    let initialDone = false;
    try {
      if (!backend) backend = window.FIELDMAP_BACKEND_FACTORY ? await window.FIELDMAP_BACKEND_FACTORY() : await FirestoreBackend.create(cfg());
      conn = await backend.subscribe(code, {
        onChanges(changes, meta) {
          changes.forEach((c) => {
            const d = fromWire(Object.assign({}, c.data, { id: c.id }));
            remoteIdx.set(c.kind + ':' + c.id, d.updatedAt || 0);
            Store.upsert(c.kind, d, { remote: true });
          });
          // локальные данные, которых нет на сервере, отправляем только после ответа самого сервера (не из кэша)
          if (!initialDone && !(meta && meta.fromCache)) { initialDone = true; pushLocalDiff(); }
        },
        onState(online, msg) { setStatus(online ? 'online' : 'offline', msg); },
      });
      Store.setMapId(code);
    } catch (e) {
      await disconnectInternal();
      setStatus('offline', friendly(e));
      throw e;
    }
  }

  Store.on((evt) => {
    if (evt.remote || !evt.item || !conn) return;
    pushOne(evt.kind, evt.item);
  });

  window.addEventListener('online', () => { if (Store.state.mapId && !conn) Sync.autostart(); });

  return {
    configured, pretty, norm,
    status: () => st,
    onStatus(f) { subs.push(f); },
    async create() { const code = newCode(); await connect(code); return code; },
    join: connect,
    async leave() { await disconnectInternal(); Store.setMapId(null); setStatus('off'); },
    autostart() {
      const id = Store.state.mapId;
      if (id && configured()) connect(id).catch((e) => logErr('Синхронизация: ' + friendly(e)));
    },
  };
})();
