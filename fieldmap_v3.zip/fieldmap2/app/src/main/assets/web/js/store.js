// ===== Хранилище для страницы FieldMap =====
// Страница работает со своим объектом S (folders, markers, lines, reels, activeFolderId, view…) и сохраняет его через Store.save().
// Общими для всех телефонов считаются папки, маркеры, линии (вместе со слоями кабелей и трубок) и бобины —
// со всеми их полями. Остальное в S (активная папка, вид карты, выбранный цвет) — личное для телефона.
// Store сравнивает S с прошлым сохранением, ставит метки времени изменённым объектам (основа синхронизации:
// побеждает более позднее изменение) и помнит удалённые объекты («надгробия»), чтобы удаление дошло до других.
// Фото маркеров лежат в IndexedDB, а в localStorage остаются только ссылки «photo:<id>» — так память не
// переполняется. Если IndexedDB недоступна, фото хранятся прямо в localStorage, как раньше.
const Store = (function () {
  const KEY = 'fieldmap_proto_v1';       // данные страницы (ключ прототипа не меняется)
  const META = 'fieldmap_sync_v1';       // метки времени, надгробия, код общей карты
  const OLD = 'fieldmap_store_v3';       // данные прошлой версии приложения: только копируются, ключ не трогаем
  const KINDS = ['folders', 'markers', 'lines', 'reels'];
  const WIRE = ['kind', 'updatedAt', 'deleted'];   // служебные поля записи, в объект не попадают

  let S = null;                                   // объект данных страницы
  let meta = { mapId: null, stamps: {}, tombs: {} };
  const last = {};                                // kind -> id -> JSON прошлой сохранённой версии
  const subs = [];                                // слушатели локальных изменений (синхронизация)
  const photoSubs = [];                           // слушатели «фото загрузилось»
  KINDS.forEach((k) => { meta.stamps[k] = {}; meta.tombs[k] = {}; last[k] = {}; });

  const num = (x) => { x = Number(x); return Number.isFinite(x) ? x : null; };
  const str = (x, n) => (x == null ? '' : String(x)).slice(0, n);
  const cleanColor = (c) => (typeof c === 'string' && /^#[0-9a-fA-F]{6}$/.test(c) ? c.toLowerCase() : null);
  const cleanId = (x) => (typeof x === 'string' && /^[\w-]{1,40}$/.test(x) ? x : null);
  const isData = (p) => typeof p === 'string' && p.startsWith('data:image/');

  // ---------- фото: id по содержимому, кэш в памяти, IndexedDB ----------
  const photoData = new Map();   // pid -> data:URL
  const photoIdOf = new Map();   // data:URL -> pid
  function hash(s) {             // cyrb53: быстрый 53-битный хеш строки
    let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
    for (let i = 0; i < s.length; i++) {
      const c = s.charCodeAt(i);
      h1 = Math.imul(h1 ^ c, 2654435761); h2 = Math.imul(h2 ^ c, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
  }
  function pidOf(p) {
    if (typeof p !== 'string') return null;
    if (p.startsWith('photo:')) return cleanId(p.slice(6));
    if (!isData(p)) return null;
    let id = photoIdOf.get(p);
    if (!id) { id = 'p' + hash(p) + p.length.toString(36); photoIdOf.set(p, id); photoData.set(id, p); }
    return id;
  }

  let idb = null;                // Promise<IDBDatabase|null>
  const stored = new Set();      // pid, которые точно записаны в IndexedDB
  function openIdb() {
    if (idb) return idb;
    idb = new Promise((resolve) => {
      try {
        const rq = indexedDB.open('fieldmap', 1);
        rq.onupgradeneeded = () => rq.result.createObjectStore('photos');
        rq.onsuccess = () => resolve(rq.result);
        rq.onerror = () => resolve(null);
        rq.onblocked = () => resolve(null);
      } catch (e) { resolve(null); }
    });
    return idb;
  }
  function idbPut(pid, data) {
    return openIdb().then((db) => new Promise((resolve) => {
      if (!db) return resolve(false);
      try {
        const tx = db.transaction('photos', 'readwrite');
        tx.objectStore('photos').put(data, pid);
        tx.oncomplete = () => { stored.add(pid); resolve(true); };
        tx.onerror = tx.onabort = () => resolve(false);
      } catch (e) { resolve(false); }
    }));
  }
  function idbGet(pids) {
    return openIdb().then((db) => new Promise((resolve) => {
      const out = new Map();
      if (!db || !pids.length) return resolve(out);
      try {
        const tx = db.transaction('photos', 'readonly'), os = tx.objectStore('photos');
        pids.forEach((pid) => { const rq = os.get(pid); rq.onsuccess = () => { if (isData(rq.result)) out.set(pid, rq.result); }; });
        tx.oncomplete = () => resolve(out);
        tx.onerror = tx.onabort = () => resolve(out);
      } catch (e) { resolve(out); }
    }));
  }

  // подставляет загруженное фото вместо ссылок «photo:<id>» во всех маркерах
  function fillPhoto(pid, data) {
    let hit = false;
    S && S.markers.forEach((m) => {
      if (!Array.isArray(m.photos)) return;
      m.photos.forEach((p, i) => { if (p === 'photo:' + pid) { m.photos[i] = data; hit = true; } });
    });
    return hit;
  }
  // фото от другого участника или из IndexedDB
  function putPhoto(pid, data) {
    pid = cleanId(pid);
    if (!pid || !isData(data) || data.length > 1100000) return;
    if (!photoData.has(pid)) { photoData.set(pid, data); photoIdOf.set(data, pid); }
    if (!stored.has(pid)) idbPut(pid, data);
    if (fillPhoto(pid, data)) photoSubs.forEach((f) => { try { f(pid); } catch (e) { console.error(e); } });
  }
  const hasPhoto = (pid) => photoData.has(pid);
  const getPhoto = (pid) => photoData.get(pid) || null;

  // ---------- проверка и приведение объектов ----------
  // объект с другого телефона: копия всех полей (кроме служебных) и проверка того, без чего страница не нарисует его
  function sanitize(kind, it) {
    if (!it || typeof it !== 'object') return null;
    const id = cleanId(it.id);
    if (!id) return null;
    const o = {};
    Object.keys(it).forEach((k) => { if (!WIRE.includes(k) && k !== '__proto__' && k !== 'constructor') o[k] = it[k]; });
    o.id = id;
    if (o.name != null) o.name = str(o.name, 200);
    if (o.description != null) o.description = str(o.description, 2000);
    if (kind === 'folders') return o;
    if (kind === 'reels') return o;
    if (kind === 'markers') {
      const lat = num(o.lat), lng = num(o.lng);
      if (lat == null || lng == null || Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
      o.lat = lat; o.lng = lng;
      o.photos = (Array.isArray(o.photos) ? o.photos : []).slice(0, 50).filter((p) => typeof p === 'string');
      return o;
    }
    if (kind === 'lines') {
      o.points = (Array.isArray(o.points) ? o.points : []).slice(0, 5000)
        .map((p) => [num(p && p[0]), num(p && p[1])])
        .filter((p) => p[0] != null && p[1] != null && Math.abs(p[0]) <= 90 && Math.abs(p[1]) <= 180);
      if (o.points.length < 2) return null;
      if (o.layers != null && !Array.isArray(o.layers)) delete o.layers;
      return o;
    }
    return null;
  }
  // каноническая форма для сравнения и отправки: все поля объекта, фото маркера — по id
  function pick(kind, it) {
    const o = Object.assign({}, it);
    if (kind === 'markers') o.photos = (Array.isArray(it.photos) ? it.photos : []).map(pidOf).filter(Boolean);
    return JSON.parse(JSON.stringify(o));
  }
  function sig(kind, it) {
    if (kind !== 'markers' || !Array.isArray(it.photos) || !it.photos.length) return JSON.stringify(it);
    return JSON.stringify(Object.assign({}, it, { photos: it.photos.map(pidOf) }));
  }

  // ---------- загрузка ----------
  function readJson(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } }

  // данные прошлой версии приложения (fieldmap_store_v3) -> модель новой страницы
  function migrateOld() {
    const o = readJson(OLD);
    if (!o || o.v !== 3 || !Array.isArray(o.folders)) return null;
    const live = (a) => (Array.isArray(a) ? a : []).filter((x) => x && !x.deleted);
    const d = {
      folders: live(o.folders).map((f) => ({ id: f.id, name: f.name || 'Папка', color: cleanColor(f.color) || '#22c55e' })),
      markers: live(o.markers).map((m) => ({ id: m.id, folderId: m.folderId, name: m.name || '', color: cleanColor(m.color),
        lat: m.lat, lng: m.lng, createdAt: m.updatedAt || Date.now(), photos: m.photo ? [m.photo] : [] })),
      lines: live(o.lines).map((l) => ({ id: l.id, folderId: l.folderId, name: l.name || '', color: cleanColor(l.color),
        points: l.points, createdAt: l.updatedAt || Date.now() })),
      activeFolderId: o.activeFolderId,
    };
    if (!d.folders.length) return null;
    // метки времени и надгробия прошлой версии сохраняем: они нужны общей карте
    KINDS.forEach((k) => (Array.isArray(o[k]) ? o[k] : []).forEach((x) => {
      if (!x || !cleanId(x.id)) return;
      if (x.deleted) meta.tombs[k][x.id] = num(x.updatedAt) || 1;
      else meta.stamps[k][x.id] = num(x.updatedAt) || 1;
    }));
    if (typeof o.mapId === 'string') meta.mapId = o.mapId;
    return d;
  }

  // возвращает сохранённые данные или null (тогда страница создаёт пример)
  function load() {
    const m = readJson(META);
    if (m && m.stamps) {
      meta.mapId = typeof m.mapId === 'string' ? m.mapId : null;
      KINDS.forEach((k) => {
        meta.stamps[k] = (m.stamps && m.stamps[k]) || {};
        meta.tombs[k] = (m.tombs && m.tombs[k]) || {};
      });
    }
    const v = readJson(KEY);
    if (v && Array.isArray(v.folders) && Array.isArray(v.markers) && Array.isArray(v.lines)) return v;
    return migrateOld();
  }

  // страница передаёт свой объект данных; запоминаем его состояние и подгружаем фото из IndexedDB
  function attach(data) {
    S = data;
    KINDS.forEach((k) => {
      S[k] = (Array.isArray(S[k]) ? S[k] : []).filter((it) => it && cleanId(it.id));
      last[k] = {};
      S[k].forEach((it) => {
        last[k][it.id] = sig(k, it);
        if (!meta.stamps[k][it.id]) meta.stamps[k][it.id] = 1;   // ещё не синхронизировался: любая версия с сервера новее
        delete meta.tombs[k][it.id];
      });
    });
    const need = [];
    S.markers.forEach((m) => (m.photos || []).forEach((p) => {
      if (typeof p === 'string' && p.startsWith('photo:')) need.push(p.slice(6));
    }));
    if (need.length) idbGet([...new Set(need)]).then((got) => got.forEach((data, pid) => { stored.add(pid); putPhoto(pid, data); }));
    // фото, уже лежащие в данных, тоже переносим в IndexedDB при следующем сохранении
    persist();
  }

  // ---------- сохранение ----------
  let persistAgain = false;
  function persist() {
    if (!S) return true;
    const pending = [];
    const out = Object.assign({}, S, {
      markers: S.markers.map((m) => {
        if (!Array.isArray(m.photos) || !m.photos.length) return m;
        return Object.assign({}, m, { photos: m.photos.map((p) => {
          const pid = pidOf(p);
          if (!pid || !isData(p)) return p;
          if (stored.has(pid)) return 'photo:' + pid;
          pending.push([pid, p]);
          return p;                       // пока не записано в IndexedDB — храним как есть
        }) });
      }),
    });
    let ok = true;
    try { localStorage.setItem(KEY, JSON.stringify(out)); } catch (e) { ok = false; }
    try { localStorage.setItem(META, JSON.stringify(meta)); } catch (e) { ok = false; }
    if (pending.length && !persistAgain) {
      persistAgain = true;
      Promise.all(pending.map(([pid, p]) => idbPut(pid, p))).then((res) => {
        persistAgain = false;
        if (res.some(Boolean)) persist();  // теперь фото в IndexedDB — пересохраняем со ссылками
      });
    }
    return ok;
  }

  function emit(evt) { subs.forEach((f) => { try { f(evt); } catch (e) { console.error(e); } }); }

  // сохраняет S: находит изменённые, новые и удалённые объекты, ставит им время и сообщает синхронизации
  function save() {
    if (!S) return true;
    const now = Date.now();
    KINDS.forEach((k) => {
      const seen = new Set();
      if (!Array.isArray(S[k])) S[k] = [];
      S[k].forEach((it) => {
        if (!it || !cleanId(it.id)) return;
        seen.add(it.id);
        const s = sig(k, it);
        if (last[k][it.id] === s) return;
        last[k][it.id] = s;
        const t = Math.max(now, (meta.stamps[k][it.id] || 0) + 1, (meta.tombs[k][it.id] || 0) + 1);
        meta.stamps[k][it.id] = t; delete meta.tombs[k][it.id];
        emit({ kind: k, rec: record(k, it) });
      });
      Object.keys(last[k]).forEach((id) => {
        if (seen.has(id)) return;
        delete last[k][id];
        const t = Math.max(now, (meta.stamps[k][id] || 0) + 1);
        delete meta.stamps[k][id]; meta.tombs[k][id] = t;
        emit({ kind: k, rec: { id, deleted: true, updatedAt: t } });
      });
    });
    return persist();
  }

  // запись для отправки на сервер
  function record(kind, it) {
    const o = pick(kind, it);
    o.updatedAt = meta.stamps[kind][it.id] || 1;
    o.deleted = false;
    return o;
  }
  // все объекты и надгробия — для первой отправки после подключения
  function allRecords(kind) {
    const out = (S[kind] || []).filter((it) => it && cleanId(it.id)).map((it) => record(kind, it));
    Object.keys(meta.tombs[kind]).forEach((id) => out.push({ id, deleted: true, updatedAt: meta.tombs[kind][id] }));
    return out;
  }

  // изменение от другого участника: применяем, только если оно новее. Объекты меняются на месте,
  // чтобы открытые на странице ссылки (перетаскивание, выделение) остались рабочими.
  function applyRemote(kind, rec) {
    if (!S || !KINDS.includes(kind) || !rec) return false;
    if (!Array.isArray(S[kind])) S[kind] = [];
    const id = cleanId(rec.id), t = num(rec.updatedAt) || 0;
    if (!id) return false;
    const mine = Math.max(meta.stamps[kind][id] || 0, meta.tombs[kind][id] || 0);
    if (mine >= t) return false;
    const arr = S[kind], i = arr.findIndex((x) => x.id === id);
    if (rec.deleted) {
      if (i >= 0) arr.splice(i, 1);
      delete last[kind][id]; delete meta.stamps[kind][id]; meta.tombs[kind][id] = t;
      return true;
    }
    const clean = sanitize(kind, rec);
    if (!clean) return false;
    if (kind === 'markers') clean.photos = clean.photos.map(cleanId).filter(Boolean).map((pid) => photoData.get(pid) || ('photo:' + pid));
    if (i >= 0) {
      const it = arr[i];
      Object.keys(it).forEach((f) => { if (!(f in clean)) delete it[f]; });
      Object.assign(it, clean);
    } else {
      arr.push(clean);
    }
    meta.stamps[kind][id] = t; delete meta.tombs[kind][id];
    last[kind][id] = sig(kind, i >= 0 ? arr[i] : clean);
    return true;
  }

  // «заменить общей картой»: убираем с телефона объекты, которых нет на сервере (без надгробий)
  function dropLocalOnly(onServer) {
    KINDS.forEach((k) => {
      S[k] = (S[k] || []).filter((it) => onServer.has(k + ':' + it.id));
      Object.keys(last[k]).forEach((id) => { if (!onServer.has(k + ':' + id)) { delete last[k][id]; delete meta.stamps[k][id]; } });
      Object.keys(meta.tombs[k]).forEach((id) => { if (!onServer.has(k + ':' + id)) delete meta.tombs[k][id]; });
    });
    persist();
  }

  window.addEventListener('pagehide', persist);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') persist(); });

  return {
    KINDS, load, attach, save, persist, applyRemote, dropLocalOnly, allRecords, sanitize,
    pidOf, putPhoto, hasPhoto, getPhoto,
    get data() { return S; },
    get mapId() { return meta.mapId; },
    setMapId(code) { meta.mapId = code || null; persist(); },
    on(fn) { subs.push(fn); },
    onPhoto(fn) { photoSubs.push(fn); },
  };
})();
