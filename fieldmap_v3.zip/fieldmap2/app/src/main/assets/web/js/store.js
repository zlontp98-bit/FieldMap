// ===== Лог ошибок в панель (если есть) =====
function logErr(msg) {
  try {
    const el = document.getElementById('errorLog');
    if (el) {
      el.style.display = 'block';
      const d = document.createElement('div');
      d.textContent = '[' + new Date().toLocaleTimeString() + '] ' + msg;
      el.appendChild(d);
      el.scrollTop = el.scrollHeight;
    } else console.error(msg);
  } catch (_) {}
}

// ===== Хранилище: папки, маркеры, линии =====
// У каждого объекта есть id и updatedAt — это основа синхронизации (побеждает более новое изменение).
// Удалённые объекты остаются как «надгробия» (deleted:true), чтобы удаление дошло до других участников.
const Store = (function () {
  const KEY = 'fieldmap_store_v3';
  // старые ключи НЕ трогаем: данные из них только копируются при первом запуске
  const OLD = { groups: 'fieldmap_groups_v1', markers: 'fieldmap_markers_v2', lines: 'fieldmap_lines_v1' };
  const PALETTE = ['#22c55e', '#3b82f6', '#ef4444', '#f59e0b', '#a855f7', '#ec4899', '#14b8a6', '#eab308', '#64748b', '#f97316'];

  // hidden — личная настройка «папка скрыта» (не синхронизируется с другими участниками)
  const s = { v: 3, folders: [], markers: [], lines: [], hidden: {}, activeFolderId: null, mapId: null, userName: '' };
  const subs = [];
  let saveTimer = null;

  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  const num = (x) => { x = Number(x); return Number.isFinite(x) ? x : null; };
  const cleanColor = (c) => (/^#[0-9a-fA-F]{6}$/.test(c || '') ? c.toLowerCase() : null);
  const cleanPhoto = (p) =>
    typeof p === 'string' && p.length < 400000 && /^data:image\/(jpeg|png|webp);base64,/.test(p) &&
    /^[A-Za-z0-9+\/=]*$/.test(p.slice(p.indexOf(',') + 1)) ? p : null;

  // Любые данные (в том числе пришедшие от других участников) проходят через эту проверку
  function sanitize(kind, it) {
    if (!it || typeof it.id !== 'string' || !/^[\w-]{1,40}$/.test(it.id)) return null;
    const base = {
      id: it.id,
      name: String(it.name == null ? '' : it.name).slice(0, 120),
      color: cleanColor(it.color),
      deleted: !!it.deleted,
      updatedAt: num(it.updatedAt) || 0,
      updatedBy: String(it.updatedBy || '').slice(0, 40),
    };
    if (kind === 'folders') return base;
    base.folderId = typeof it.folderId === 'string' ? it.folderId.slice(0, 40) : null;
    if (kind === 'markers') {
      const lat = num(it.lat), lng = num(it.lng);
      if (lat == null || lng == null || Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
      base.lat = lat; base.lng = lng;
      base.photo = it.deleted ? null : cleanPhoto(it.photo);
      return base;
    }
    if (kind === 'lines') {
      let pts = Array.isArray(it.points) ? it.points : [];
      pts = pts.slice(0, 5000).map((p) => [num(p && p[0]), num(p && p[1])]).filter((p) => p[0] != null && p[1] != null);
      if (!it.deleted && pts.length < 2) return null;
      base.points = pts;
      return base;
    }
    return null;
  }

  function emit(evt) { subs.forEach((f) => { try { f(evt); } catch (e) { logErr('store listener: ' + (e && e.message || e)); } }); }

  function flush() {
    clearTimeout(saveTimer); saveTimer = null;
    try { localStorage.setItem(KEY, JSON.stringify(s)); }
    catch (e) { logErr('Не удалось сохранить данные: ' + (e && e.message || e)); }
  }
  function scheduleSave() { if (!saveTimer) saveTimer = setTimeout(flush, 150); }

  function live(kind) { return s[kind].filter((x) => !x.deleted); }
  function get(kind, id) { return s[kind].find((x) => x.id === id) || null; }

  // remote:true — изменение пришло от другого участника: применяем, только если оно новее
  function upsert(kind, item, opts) {
    opts = opts || {};
    const clean = sanitize(kind, item);
    if (!clean) return false;
    const arr = s[kind];
    const i = arr.findIndex((x) => x.id === clean.id);
    if (opts.remote) {
      if (i >= 0 && (arr[i].updatedAt || 0) >= clean.updatedAt) return false;
    } else {
      clean.updatedAt = Math.max(Date.now(), (i >= 0 ? arr[i].updatedAt : 0) + 1);
      clean.updatedBy = s.userName || '';
    }
    if (i >= 0) arr[i] = clean; else arr.push(clean);
    scheduleSave();
    emit({ kind, id: clean.id, remote: !!opts.remote, item: clean });
    return true;
  }

  function remove(kind, id) {
    const it = get(kind, id);
    if (!it || it.deleted) return;
    const t = Object.assign({}, it, { deleted: true, photo: null });
    if (kind === 'lines') t.points = [];
    upsert(kind, t);
  }

  function ensureDefaultFolder() {
    if (live('folders').length) return;
    const f = { id: uid(), name: 'Папка по умолчанию', color: PALETTE[0] };
    upsert('folders', f);
    s.activeFolderId = f.id;
  }

  function deleteFolder(id) {
    live('markers').filter((m) => m.folderId === id).forEach((m) => remove('markers', m.id));
    live('lines').filter((l) => l.folderId === id).forEach((l) => remove('lines', l.id));
    remove('folders', id);
    ensureDefaultFolder();
    if (!get('folders', s.activeFolderId) || get('folders', s.activeFolderId).deleted) s.activeFolderId = live('folders')[0].id;
    scheduleSave();
    emit({ kind: 'meta' });
  }

  function migrateOld() {
    const rd = (k) => { try { return JSON.parse(localStorage.getItem(k)); } catch (_) { return null; } };
    const g = rd(OLD.groups), m = rd(OLD.markers), l = rd(OLD.lines);
    if (!g && !m && !l) return false;
    const now = Date.now();
    const folders = (g && Array.isArray(g.groups)) ? g.groups : [];
    folders.forEach((x, i) => {
      const f = sanitize('folders', { id: String(x.id), name: x.name || 'Папка', color: PALETTE[i % PALETTE.length], updatedAt: now });
      if (f) { s.folders.push(f); if (x.visible === false) s.hidden[f.id] = true; }
    });
    if (!s.folders.length) ensureDefaultFolder();
    const first = s.folders[0].id;
    const known = new Set(s.folders.map((f) => f.id));
    (Array.isArray(m) ? m : []).forEach((d) => {
      const it = sanitize('markers', { id: uid(), folderId: known.has(d.groupId) ? d.groupId : first, lat: d.lat, lng: d.lng, name: d.name || '', photo: d.photo && d.photo.src, updatedAt: now });
      if (it) s.markers.push(it);
    });
    (Array.isArray(l) ? l : []).forEach((d) => {
      const it = sanitize('lines', { id: uid(), folderId: known.has(d.groupId) ? d.groupId : first, name: d.name || '', points: d.points, updatedAt: now });
      if (it) s.lines.push(it);
    });
    s.activeFolderId = (g && known.has(g.activeGroupId)) ? g.activeGroupId : first;
    return true;
  }

  function load() {
    let saved = null;
    try { saved = JSON.parse(localStorage.getItem(KEY)); } catch (e) { logErr('Store.load: ' + (e && e.message || e)); }
    if (saved && saved.v === 3) {
      Object.assign(s, saved);
    } else if (!migrateOld()) {
      ensureDefaultFolder();
    }
    ensureDefaultFolder();
    const act = get('folders', s.activeFolderId);
    if (!act || act.deleted) s.activeFolderId = live('folders')[0].id;
    flush();
  }

  window.addEventListener('pagehide', flush);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(); });

  return {
    PALETTE, uid, load, flush, upsert, remove, deleteFolder, get, live, sanitize, cleanColor,
    state: s,
    on(fn) { subs.push(fn); },
    setActive(id) { s.activeFolderId = id; scheduleSave(); emit({ kind: 'meta' }); },
    isHidden(id) { return !!s.hidden[id]; },
    setHidden(id, v) { if (v) s.hidden[id] = true; else delete s.hidden[id]; scheduleSave(); emit({ kind: 'meta' }); },
    setMapId(code) { s.mapId = code || null; scheduleSave(); emit({ kind: 'meta' }); },
    setUserName(n) { s.userName = String(n || '').slice(0, 40); scheduleSave(); emit({ kind: 'meta' }); },
    folderColor(id) { const f = get('folders', id); return (f && f.color) || PALETTE[0]; },
  };
})();
