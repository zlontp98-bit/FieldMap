// ===== Хранилище для страницы FieldMap =====
// Страница работает со своим объектом S (folders, markers, lines, reels, activeFolderId, view…) и сохраняет его через Store.save().
// Общими для всех телефонов считаются объекты (папки), маркеры, линии (вместе со слоями кабелей и трубок) и бобины —
// со всеми их полями. Остальное в S — личное для телефона: режим «Проект/Выполнение», авто-цвет, журнал работ
// (log, logSnap), места в отчёте, выбранные цвета, вид карты.
// Store сравнивает S с прошлым сохранением, ставит метки времени изменённым объектам (основа синхронизации:
// побеждает более позднее изменение) и помнит удалённые объекты («надгробия»), чтобы удаление дошло до других.
// Изменённым объектам Store сам ставит createdBy/updatedBy — uid аккаунта (когда вошли через Google).
//
// Фото. В данных у маркера и линии — список photos. Элемент — либо строка «photo:<id>» (старые фото и фото из галереи),
// либо запись снимка камеры { id, lat, lng, t, by, gps?, acc? }. Сами картинки лежат в IndexedDB по id, а в данные не
// попадают. Чужие фото скачиваются с общей карты только при открытии (photoGet → загрузчик из sync.js).
const Store = (function () {
  const KEY = 'fieldmap_proto_v1';       // данные страницы (ключ прототипа не меняется)
  const META = 'fieldmap_sync_v1';       // метки времени, надгробия, код общей карты, отправленные фото
  const OLD = 'fieldmap_store_v3';       // данные прошлой версии приложения: только копируются, ключ не трогаем
  const KINDS = ['folders', 'markers', 'lines', 'reels'];
  const WIRE = ['kind', 'updatedAt', 'deleted'];   // служебные поля записи, в объект не попадают
  const WITH_PHOTOS = ['markers', 'lines'];

  let S = null;                                   // объект данных страницы
  // sent: { код карты: { id фото: 1 } } — фото, которые точно есть на общей карте (их не отправляем ещё раз)
  let meta = { mapId: null, stamps: {}, tombs: {}, sent: {}, v4: false };
  const last = {};                                // kind -> id -> подпись прошлой сохранённой версии
  const subs = [];                                // слушатели локальных изменений (синхронизация)
  let myUid = null;                               // uid аккаунта: createdBy/updatedBy
  KINDS.forEach((k) => { meta.stamps[k] = {}; meta.tombs[k] = {}; last[k] = {}; });

  const num = (x) => { x = Number(x); return Number.isFinite(x) ? x : null; };
  const str = (x, n) => (x == null ? '' : String(x)).slice(0, n);
  const cleanColor = (c) => (typeof c === 'string' && /^#[0-9a-fA-F]{6}$/.test(c) ? c.toLowerCase() : null);
  const cleanId = (x) => (typeof x === 'string' && /^[\w-]{1,40}$/.test(x) ? x : null);
  const isData = (p) => typeof p === 'string' && p.startsWith('data:image/');

  // ---------- фото: IndexedDB, немного в памяти, загрузка с общей карты по запросу ----------
  function hash(s) {             // cyrb53: быстрый 53-битный хеш строки
    let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
    for (let i = 0; i < s.length; i++) {
      const c = s.charCodeAt(i);
      h1 = Math.imul(h1 ^ c, 2654435761); h2 = Math.imul(h2 ^ c, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
  }
  // id фото по самой картинке (так было в прошлых версиях: одинаковая картинка — один id)
  const dataId = (d) => 'p' + hash(d) + d.length.toString(36);
  // id фото из элемента списка photos (строка или запись снимка)
  function photoIdOf(p) {
    if (typeof p === 'string') {
      if (p.startsWith('photo:')) return cleanId(p.slice(6));
      if (isData(p)) return dataId(p);
      return cleanId(p);
    }
    return p && typeof p === 'object' ? cleanId(p.id) : null;
  }

  const mem = new Map();         // id -> data:URL, последние открытые (не больше MEM_MAX)
  const MEM_MAX = 40;
  const pinned = new Map();      // id -> data:URL, ещё не записанные в IndexedDB (держим, пока не запишутся)
  function memSet(id, d) { mem.delete(id); mem.set(id, d); while (mem.size > MEM_MAX) mem.delete(mem.keys().next().value); }

  let idb = null;                // Promise<IDBDatabase|null>
  function openIdb() {
    if (idb) return idb;
    idb = new Promise((resolve) => {
      try {
        const rq = indexedDB.open('fieldmap', 1);
        rq.onupgradeneeded = () => rq.result.createObjectStore('photos');
        rq.onsuccess = () => resolve(rq.result);
        rq.onerror = () => resolve(null);
        rq.onblocked = () => resolve(null);
      } catch (e) { resolve(null); }
    });
    return idb;
  }
  function idbRun(mode, fn) {
    return openIdb().then((db) => new Promise((resolve) => {
      if (!db) return resolve(null);
      try {
        const tx = db.transaction('photos', mode), rq = fn(tx.objectStore('photos'));
        tx.oncomplete = () => resolve(rq && rq.result !== undefined ? rq.result : true);
        tx.onerror = tx.onabort = () => resolve(null);
      } catch (e) { resolve(null); }
    }));
  }
  const idbPut = (id, d) => idbRun('readwrite', (s) => s.put(d, id)).then((r) => r !== null);
  const idbGet = (id) => idbRun('readonly', (s) => s.get(id)).then((v) => (isData(v) ? v : null));

  let fetcher = null;            // (id) => Promise<data:URL|null> — ставит sync.js (скачивание с общей карты)
  const inflight = new Map();
  // картинка, если она уже есть на телефоне (без интернета)
  async function photoLocal(id) {
    id = cleanId(id);
    if (!id) return null;
    if (pinned.has(id)) return pinned.get(id);
    if (mem.has(id)) { const d = mem.get(id); memSet(id, d); return d; }
    const d = await idbGet(id);
    if (d) memSet(id, d);
    return d;
  }
  // картинка для показа: с телефона, а если её здесь нет — с общей карты (один раз, потом лежит в IndexedDB)
  async function photoGet(id) {
    id = cleanId(id);
    if (!id) return null;
    const d = await photoLocal(id);
    if (d || !fetcher) return d;
    if (inflight.has(id)) return inflight.get(id);
    const p = Promise.resolve().then(() => fetcher(id)).catch(() => null).then((data) => {
      inflight.delete(id);
      if (!isData(data)) return null;
      memSet(id, data);
      idbPut(id, data);
      markSent(id);               // пришло с общей карты — значит, там оно уже есть
      return data;
    });
    inflight.set(id, p);
    return p;
  }
  // новое фото с этого телефона; true — записано в IndexedDB
  async function photoPut(id, data) {
    id = cleanId(id);
    if (!id || !isData(data)) return false;
    pinned.set(id, data); memSet(id, data);
    const ok = await idbPut(id, data);
    if (ok) pinned.delete(id);
    return ok;
  }
  async function photoDel(id) {
    id = cleanId(id);
    if (!id) return;
    mem.delete(id); pinned.delete(id);
    await idbRun('readwrite', (s) => s.delete(id));
  }
  async function photoKeys() {
    const v = await idbRun('readonly', (s) => s.getAllKeys());
    return Array.isArray(v) ? v.map(String) : [];
  }

  // какие фото уже есть на общей карте (по коду карты)
  function sentMap() {
    if (!meta.mapId) return null;
    if (!meta.sent[meta.mapId]) meta.sent[meta.mapId] = {};
    return meta.sent[meta.mapId];
  }
  function markSent(id) { const m = sentMap(); if (m && id && !m[id]) { m[id] = 1; persistSoon(); } }
  function isSent(id) { const m = sentMap(); return !!(m && m[id]); }

  // фото прямо в данных (data:URL из галереи или импорта, запись снимка со своей картинкой src) — в IndexedDB,
  // в данных остаётся ссылка. Меняет список на месте.
  function normalizePhotos(it) {
    if (!it || !Array.isArray(it.photos)) return;
    it.photos.forEach((p, i) => {
      if (isData(p)) {
        const id = dataId(p);
        photoPut(id, p);
        it.photos[i] = 'photo:' + id;
      } else if (p && typeof p === 'object' && isData(p.src) && cleanId(p.id)) {
        const src = p.src;
        photoPut(p.id, src).then((ok) => { if (ok && p.src === src) { delete p.src; persistSoon(); } });
      }
    });
  }
  // фото в записи для общей карты: старые — просто id (как в прошлых версиях), снимки — запись без картинки
  function wirePhotos(list) {
    return (Array.isArray(list) ? list : []).map((p) => {
      if (typeof p === 'string') return photoIdOf(p);
      if (!p || typeof p !== 'object' || !cleanId(p.id)) return null;
      const o = Object.assign({}, p);
      delete o.src;
      return o;
    }).filter(Boolean);
  }
  // фото из записи с общей карты
  function cleanPhotos(list) {
    return (Array.isArray(list) ? list : []).slice(0, 200).map((p) => {
      if (typeof p === 'string') { const id = photoIdOf(p); return id ? 'photo:' + id : null; }
      if (!p || typeof p !== 'object') return null;
      const id = cleanId(p.id);
      if (!id) return null;
      const o = { id };
      ['lat', 'lng', 't', 'acc'].forEach((k) => { const v = num(p[k]); if (v != null) o[k] = v; });
      if (typeof p.by === 'string') o.by = p.by.slice(0, 128);
      if (p.gps) o.gps = true;
      return o;
    }).filter(Boolean);
  }
  // id всех фото записи (строки и снимки)
  const photoIds = (list) => (Array.isArray(list) ? list : []).map(photoIdOf).filter(Boolean);

  // ---------- проверка и приведение объектов ----------
  // объект с другого телефона: копия всех полей (кроме служебных) и проверка того, без чего страница не нарисует его
  function sanitize(kind, it) {
    if (!it || typeof it !== 'object') return null;
    const id = cleanId(it.id);
    if (!id) return null;
    const o = {};
    Object.keys(it).forEach((k) => { if (!WIRE.includes(k) && k !== '__proto__' && k !== 'constructor') o[k] = it[k]; });
    o.id = id;
    if (o.name != null) o.name = str(o.name, 200);
    if (o.description != null) o.description = str(o.description, 2000);
    if (kind === 'folders') return o;
    if (kind === 'reels') return o;
    if (kind === 'markers') {
      const lat = num(o.lat), lng = num(o.lng);
      if (lat == null || lng == null || Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
      o.lat = lat; o.lng = lng;
      o.photos = cleanPhotos(o.photos);
      return o;
    }
    if (kind === 'lines') {
      o.points = (Array.isArray(o.points) ? o.points : []).slice(0, 5000)
        .map((p) => [num(p && p[0]), num(p && p[1])])
        .filter((p) => p[0] != null && p[1] != null && Math.abs(p[0]) <= 90 && Math.abs(p[1]) <= 180);
      if (o.points.length < 2) return null;
      if (o.layers != null && !Array.isArray(o.layers)) delete o.layers;
      if (o.photos != null) o.photos = cleanPhotos(o.photos);
      return o;
    }
    return null;
  }
  // каноническая форма для сравнения и отправки: все поля объекта, фото — без картинок
  function pick(kind, it) {
    const o = Object.assign({}, it);
    if (WITH_PHOTOS.includes(kind) && Array.isArray(it.photos)) o.photos = wirePhotos(it.photos);
    return JSON.parse(JSON.stringify(o));
  }
  const sig = (kind, it) => JSON.stringify(pick(kind, it));

  // ---------- загрузка ----------
  function readJson(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } }

  // данные самой первой версии приложения (fieldmap_store_v3) -> модель страницы
  function migrateOld() {
    const o = readJson(OLD);
    if (!o || o.v !== 3 || !Array.isArray(o.folders)) return null;
    const live = (a) => (Array.isArray(a) ? a : []).filter((x) => x && !x.deleted);
    const d = {
      folders: live(o.folders).map((f) => ({ id: f.id, name: f.name || 'Объект', color: cleanColor(f.color) || '#22c55e' })),
      markers: live(o.markers).map((m) => ({ id: m.id, folderId: m.folderId, name: m.name || '', color: cleanColor(m.color),
        lat: m.lat, lng: m.lng, createdAt: m.updatedAt || Date.now(), photos: m.photo ? [m.photo] : [] })),
      lines: live(o.lines).map((l) => ({ id: l.id, folderId: l.folderId, name: l.name || '', color: cleanColor(l.color),
        points: l.points, createdAt: l.updatedAt || Date.now() })),
      activeFolderId: o.activeFolderId,
    };
    if (!d.folders.length) return null;
    // метки времени и надгробия прошлой версии сохраняем: они нужны общей карте
    KINDS.forEach((k) => (Array.isArray(o[k]) ? o[k] : []).forEach((x) => {
      if (!x || !cleanId(x.id)) return;
      if (x.deleted) meta.tombs[k][x.id] = num(x.updatedAt) || 1;
      else meta.stamps[k][x.id] = num(x.updatedAt) || 1;
    }));
    if (typeof o.mapId === 'string') meta.mapId = o.mapId;
    return d;
  }

  // возвращает сохранённые данные или null (тогда страница начинает с пустой карты)
  function load() {
    const m = readJson(META);
    if (m && m.stamps) {
      meta.mapId = typeof m.mapId === 'string' ? m.mapId : null;
      meta.sent = m.sent && typeof m.sent === 'object' ? m.sent : {};
      meta.v4 = !!m.v4;
      KINDS.forEach((k) => {
        meta.stamps[k] = (m.stamps && m.stamps[k]) || {};
        meta.tombs[k] = (m.tombs && m.tombs[k]) || {};
      });
    }
    const v = readJson(KEY);
    if (v && Array.isArray(v.folders) && Array.isArray(v.markers) && Array.isArray(v.lines)) return v;
    return migrateOld();
  }

  // страница передаёт свой объект данных; запоминаем его состояние
  function attach(data) {
    S = data;
    KINDS.forEach((k) => {
      S[k] = (Array.isArray(S[k]) ? S[k] : []).filter((it) => it && cleanId(it.id));
      last[k] = {};
      S[k].forEach((it) => {
        if (WITH_PHOTOS.includes(k)) normalizePhotos(it);
        last[k][it.id] = sig(k, it);
        if (!meta.stamps[k][it.id]) meta.stamps[k][it.id] = 1;   // ещё не синхронизировался: любая версия с сервера новее
        delete meta.tombs[k][it.id];
      });
    });
    // обновление с версии 3.x: все фото, которые уже были у телефона общей карты, прошлая версия туда отправила
    if (!meta.v4) {
      const m = sentMap();
      if (m) WITH_PHOTOS.forEach((k) => S[k].forEach((it) => photoIds(it.photos).forEach((id) => { m[id] = 1; })));
      meta.v4 = true;
    }
    persist();
  }

  // ---------- сохранение ----------
  function persist() {
    if (!S) return true;
    let out = S;
    // фото, которые ещё не записались в IndexedDB, сохраняем прямо в данных (как раньше), чтобы не потерять
    if (pinned.size) {
      const fix = (it) => {
        if (!Array.isArray(it.photos) || !it.photos.some((p) => typeof p === 'string' && pinned.has(photoIdOf(p)))) return it;
        return Object.assign({}, it, { photos: it.photos.map((p) => (typeof p === 'string' && pinned.has(photoIdOf(p)) ? pinned.get(photoIdOf(p)) : p)) });
      };
      out = Object.assign({}, S, { markers: S.markers.map(fix), lines: S.lines.map(fix) });
    }
    let ok = true;
    try { localStorage.setItem(KEY, JSON.stringify(out)); } catch (e) { ok = false; }
    try { localStorage.setItem(META, JSON.stringify(meta)); } catch (e) { ok = false; }
    return ok;
  }
  let persistTimer = null;
  function persistSoon() { clearTimeout(persistTimer); persistTimer = setTimeout(persist, 500); }

  function emit(evt) { subs.forEach((f) => { try { f(evt); } catch (e) { console.error(e); } }); }

  // сохраняет S: находит изменённые, новые и удалённые объекты, ставит им время и сообщает синхронизации
  function save() {
    if (!S) return true;
    const now = Date.now();
    KINDS.forEach((k) => {
      const seen = new Set();
      if (!Array.isArray(S[k])) S[k] = [];
      S[k].forEach((it) => {
        if (!it || !cleanId(it.id)) return;
        seen.add(it.id);
        if (WITH_PHOTOS.includes(k)) normalizePhotos(it);
        let s = sig(k, it);
        if (last[k][it.id] === s) return;
        // кто поставил и кто последним менял — uid аккаунта
        if (myUid) {
          if (!it.createdBy && !last[k][it.id]) it.createdBy = myUid;
          it.updatedBy = myUid;
          s = sig(k, it);
        }
        last[k][it.id] = s;
        const t = Math.max(now, (meta.stamps[k][it.id] || 0) + 1, (meta.tombs[k][it.id] || 0) + 1);
        meta.stamps[k][it.id] = t; delete meta.tombs[k][it.id];
        emit({ kind: k, rec: record(k, it) });
      });
      Object.keys(last[k]).forEach((id) => {
        if (seen.has(id)) return;
        delete last[k][id];
        const t = Math.max(now, (meta.stamps[k][id] || 0) + 1);
        delete meta.stamps[k][id]; meta.tombs[k][id] = t;
        emit({ kind: k, rec: { id, deleted: true, updatedAt: t } });
      });
    });
    return persist();
  }

  // запись для отправки на сервер
  function record(kind, it) {
    const o = pick(kind, it);
    o.updatedAt = meta.stamps[kind][it.id] || 1;
    o.deleted = false;
    return o;
  }
  // все объекты и надгробия — для первой отправки после подключения
  function allRecords(kind) {
    const out = (S[kind] || []).filter((it) => it && cleanId(it.id)).map((it) => record(kind, it));
    Object.keys(meta.tombs[kind]).forEach((id) => out.push({ id, deleted: true, updatedAt: meta.tombs[kind][id] }));
    return out;
  }

  // изменение от другого участника: применяем, только если оно новее. Объекты меняются на месте,
  // чтобы открытые на странице ссылки (перетаскивание, выделение) остались рабочими.
  function applyRemote(kind, rec) {
    if (!S || !KINDS.includes(kind) || !rec) return false;
    if (!Array.isArray(S[kind])) S[kind] = [];
    const id = cleanId(rec.id), t = num(rec.updatedAt) || 0;
    if (!id) return false;
    const mine = Math.max(meta.stamps[kind][id] || 0, meta.tombs[kind][id] || 0);
    if (mine >= t) return false;
    const arr = S[kind], i = arr.findIndex((x) => x.id === id);
    if (rec.deleted) {
      if (i >= 0) arr.splice(i, 1);
      delete last[kind][id]; delete meta.stamps[kind][id]; meta.tombs[kind][id] = t;
      return true;
    }
    const clean = sanitize(kind, rec);
    if (!clean) return false;
    if (i >= 0) {
      const it = arr[i];
      Object.keys(it).forEach((f) => { if (!(f in clean)) delete it[f]; });
      Object.assign(it, clean);
    } else {
      arr.push(clean);
    }
    meta.stamps[kind][id] = t; delete meta.tombs[kind][id];
    last[kind][id] = sig(kind, i >= 0 ? arr[i] : clean);
    return true;
  }

  // «заменить общей картой»: убираем с телефона объекты, которых нет на сервере (без надгробий)
  function dropLocalOnly(onServer) {
    KINDS.forEach((k) => {
      S[k] = (S[k] || []).filter((it) => onServer.has(k + ':' + it.id));
      Object.keys(last[k]).forEach((id) => { if (!onServer.has(k + ':' + id)) { delete last[k][id]; delete meta.stamps[k][id]; } });
      Object.keys(meta.tombs[k]).forEach((id) => { if (!onServer.has(k + ':' + id)) delete meta.tombs[k][id]; });
    });
    persist();
  }

  window.addEventListener('pagehide', persist);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') persist(); });

  return {
    KINDS, WITH_PHOTOS, load, attach, save, persist, applyRemote, dropLocalOnly, allRecords, sanitize,
    photoGet, photoLocal, photoPut, photoDel, photoKeys, photoIds, photoIdOf, isSent, markSent,
    setPhotoFetcher(fn) { fetcher = fn; },
    setUser(uid) { myUid = typeof uid === 'string' && uid ? uid : null; },
    get uid() { return myUid; },
    get data() { return S; },
    get mapId() { return meta.mapId; },
    setMapId(code) { meta.mapId = code || null; persist(); },
    on(fn) { subs.push(fn); },
  };
})();
