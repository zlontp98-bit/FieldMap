// Вставьте сюда настройки вашего проекта Firebase:
// Firebase Console -> Project settings -> Your apps -> Web app -> "firebaseConfig".
// Пока здесь YOUR_..., синхронизация выключена, приложение работает автономно.
window.FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  appId: "YOUR_APP_ID"
};
