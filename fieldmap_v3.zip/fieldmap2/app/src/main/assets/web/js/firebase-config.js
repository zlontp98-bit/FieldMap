// Настройки проекта Firebase (Firebase Console -> Project settings -> Your apps -> Web app -> "firebaseConfig").
// Эти ключи не секретные: доступ к данным ограничивают правила Firestore (firestore.rules).
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyAptwDMNhdG6TID0U0V5Civr6hfJJfxmBU",
  authDomain: "fieldmap-afaf2.firebaseapp.com",
  projectId: "fieldmap-afaf2",
  storageBucket: "fieldmap-afaf2.firebasestorage.app",
  messagingSenderId: "850286455853",
  appId: "1:850286455853:web:e1c14c50e7239776b9dca4"
};
// Вход через Google: Web client ID проекта (Firebase → Authentication → Sign-in method → Google →
// «Web SDK configuration» → Web client ID, кончается на .apps.googleusercontent.com). Тоже не секрет.
window.GOOGLE_WEB_CLIENT_ID = "";
